#include <18F4685.h>
//#device ICD=true
#use delay(clock=40000000,crystal=10000000)
#fuses NOWDT,PUT,WDT128,NOBROWNOUT,NOLVP,NOXINST

#define NUM_OF_LIGHTS   35
#include "picRobotics.h"
int32 timerHigh = 0;
int32 period = 0;
int32 cent = 0;
int32 target = 0;
int8 color = 0;
int8 revWait = 0;
int8 slideIndex = 0;

void clear()
{
	spi_write(0);
	spi_write(0);
	spi_write(0);
	spi_write(0);
	for(int i = 0; i<NUM_OF_LIGHTS+NUM_OF_LIGHTS;i++)
	{
		spi_write(0xFF);
		spi_write(0);
		spi_write(0);
		spi_write(0);
	}	
}	
void Display(int8 row)
{
	int i = 0;
	spi_write(0);
	spi_write(0);
	spi_write(0);
	spi_write(0);
	int inv = row+64;
	if (inv>128)
		inv-=128;
	int16 rowLoc = (int16)(row)*35;
	int16 rowLocAlt = (int16)(inv)*35;
	if (slideIndex==0)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue0[0][rowLoc+i]);
			spi_write(green0[0][rowLoc+i]);
			spi_write(red0[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue0[0][rowLocAlt+i]);
			spi_write(green0[0][rowLocAlt+i]);
			spi_write(red0[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==1)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue1[0][rowLoc+i]);
			spi_write(green1[0][rowLoc+i]);
			spi_write(red1[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue1[0][rowLocAlt+i]);
			spi_write(green1[0][rowLocAlt+i]);
			spi_write(red1[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==2)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue2[0][rowLoc+i]);
			spi_write(green2[0][rowLoc+i]);
			spi_write(red2[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue2[0][rowLocAlt+i]);
			spi_write(green2[0][rowLocAlt+i]);
			spi_write(red2[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==3)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue3[0][rowLoc+i]);
			spi_write(green3[0][rowLoc+i]);
			spi_write(red3[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue3[0][rowLocAlt+i]);
			spi_write(green3[0][rowLocAlt+i]);
			spi_write(red3[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==4)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue4[0][rowLoc+i]);
			spi_write(green4[0][rowLoc+i]);
			spi_write(red4[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue4[0][rowLocAlt+i]);
			spi_write(green4[0][rowLocAlt+i]);
			spi_write(red4[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==5)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue5[0][rowLoc+i]);
			spi_write(green5[0][rowLoc+i]);
			spi_write(red5[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue5[0][rowLocAlt+i]);
			spi_write(green5[0][rowLocAlt+i]);
			spi_write(red5[0][rowLocAlt+i]);
		}
	}
	else if (slideIndex==6)
	{
		for(; i<NUM_OF_LIGHTS;i++)
		{
			spi_write(0xFF);
			spi_write(blue6[0][rowLoc+i]);
			spi_write(green6[0][rowLoc+i]);
			spi_write(red6[0][rowLoc+i]);
		}
		for(i = NUM_OF_LIGHTS-1; i!=255;i--)
		{
			spi_write(0xFF);
			spi_write(blue6[0][rowLocAlt+i]);
			spi_write(green6[0][rowLocAlt+i]);
			spi_write(red6[0][rowLocAlt+i]);
		}
	}
}	
	
void Main()
{
	set_tris_a(0b00000001);
	set_tris_b(0b00101110);
	set_tris_c(0b00010111);
	setup_spi(SPI_MASTER | SPI_L_TO_H   | SPI_XMIT_L_TO_H );
	setup_timer_0(RTCC_DIV_64);
	ext_int_edge( 1, H_TO_L); //pin B2
	enable_interrupts(INT_TIMER0);
	enable_interrupts(INT_EXT1);
	enable_interrupts(GLOBAL);
	clear();
	while(true)
	{
		if((timerHigh + get_timer0()) > target)
		{
			if(target>(period+cent+cent+cent))
			{
				clear();	   
			} 
			else	
			{
				display(color);
				target+=cent;
				color++;	
			}	
		}
	}	
}
#INT_TIMER0
void TimerOverflow()
{
	timerHigh+=65536;
}	
#INT_EXT1	
void Cycled()
{
	period = timerHigh+get_timer0();
	cent = period/128;
	set_timer0(0);
	revWait++;	
	if(revWait==128)
	{
		revWait = 0;
		if(++slideIndex == NUM_OF_SLIDES)
		{
			slideIndex = 0;
		}	
	}
	target = cent;
	color = 1;
	timerHigh = 0;
}	