//////////////////////////////////////////////////////////////////////////
//	diskio.h include file with low level SD/MMC Card I/O functions
//	CCS PICC Specific file for the PIC18F series PIC
//
//	This file contains an implementation of the FatFs file system diskio.h
//	which has been ported to the Microchip PIC18F product family and the CCS PICC
//	C compiler.
//
//	The original file system is located at: http://elm-chan.org/fsw/ff/00index_e.html
//
//	Hardware Revision: 
//		LIA_ENC - LIA PIC18F4620/ENC28J60 Ethernet & SD Controller Rev 0.2
//
//		Copyright (c) 2006, Andrew Smallridge
//		Copyright (c) 2006, ChaN
//
//		Last Modified 26/09/06
//
///////////////////////////////////////////////////////////////////////////

#ifndef _DISKIF

///////////////////////////////////////////////////////////////////////////
//		Debug Defines
///////////////////////////////////////////////////////////////////////////
//#define SD_INIT_TRACE TRUE

///////////////////////////////////////////////////////////////////////////

	// Define the SD/MMS assignments
#define SelectSD bit_clear(SD_CS);
#define DeselectSD bit_set(SD_CS);

typedef unsigned char	DSTATUS;
typedef unsigned char	DRESULT;

#ifndef DWORD
	#define DWORD int32
#endif

#ifndef WORD
	#define WORD int16
#endif

enum FAT_type {FatUnknown, Fat12, Fat16, Fat32};
enum Card_type {None_Present, Unknown, MMC, SD};

///////////////////////////////////////////////////////////////////////////
//	External platform specific user function to return a FAT Time
///////////////////////////////////////////////////////////////////////////
// DWORD get_fattime(void)
//
//	31-25: Year(0-127 +1980), 24-21: Month(1-12), 20-16: Day(1-31)
//	15-11: Hour(0-23), 10-5: Minute(0-59), 4-0: Second(0-29 *2)
///////////////////////////////////////////////////////////////////////////
DWORD get_fattime(void);


///////////////////////////////////////////////////////////////////////////
// Prototypes for disk control functions 
///////////////////////////////////////////////////////////////////////////
#separate
DSTATUS disk_initialize(void);

#separate
DSTATUS disk_shutdown(void);

#separate
DSTATUS disk_status(void);

#separate
DRESULT disk_read (BYTE* Buffer, DWORD SectorNumber, BYTE SectorCount);

#separate
int SD_cmd(BYTE cmd, int32 address);

#ifndef	_READONLY
	#separate
	DRESULT disk_write (BYTE *Buffer, DWORD SectorNumber, BYTE SectorCount);
#endif
#separate
DRESULT disk_ioctl (BYTE ctrl, void *buff);

#separate
BOOLEAN SD_write_data(BYTE *ptr, BYTE token);



///////////////////////////////////////////////////////////////////////////
//		Define constants
///////////////////////////////////////////////////////////////////////////
#define SD_MAX_DIR_NAME_LENGTH		64			// maximum directory name length
	
	// Results of Disk Functions (DRESULT) 
#define RES_OK			0		// Successful 
#define	RES_ERROR		1		// R/W Error 
#define	RES_WRPRT		2		// Write Protected 
#define	RES_NOTRDY		3		// Not Ready 
#define	RES_PARERR		4		// Invalid Parameter 


	// Disk Status Bits (DSTATUS) 
#define STA_NOINIT		0x01	// Drive not initialized 
#define STA_NODISK		0x02	// No medium in the drive 
#define STA_PROTECT		0x04	// Write protected 


	// Command code for disk_ioctrl() 
#define GET_SECTORS		1
#define PUT_IDLE_STATE	2
#define SD_GET_CSD		10
#define SD_GET_CID		11
#define SD_GET_OCR		12
#define ATA_GET_REV		20
#define ATA_GET_MODEL	21
#define ATA_GET_SN		22

// Define SD command constants
#define SD_CMD_GO_IDLE_STATE		0x40	// 0
#define SD_CMD_SEND_OP_COND			0x41	// 1
#define SD_CMD_SEND_CSD				0x49	// 9
#define SD_CMD_SEND_CID				0x4A	// 10
#define SD_CMD_STOP_TX				0x4C	// 12
#define SD_CMD_SEND_STATUS			0x4D	// 13
#define SD_CMD_SET_BLOCKLEN			0x50	// 16
#define SD_CMD_READ_BLOCK			0x51	// 17
#define SD_CMD_READ_MULTIBLOCK		0x52	// 18
#define SD_CMD_WRITE_BLOCK			0x58	// 24
#define SD_CMD_WRITE_MULTIBLOCK		0x59	// 25
#define SD_CMD_SD_SEND_OP_COND		0x69	// 41
#define SD_CMD_APPL_CMD				0x77	// 55 SD application command prefix
#define SD_CMD_SEND_OCR				0x7A	// 58

#define SD_BlockSize 512
#define MaxSectorCount 1
///////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////
//		Declare Driver Variables
///////////////////////////////////////////////////////////////////////////
Card_type Card = None_Present;
FAT_type fat;				// type of FAT system installed
int32 block_size; 			// current MMC block size
static volatile DSTATUS Media_Status = STA_NOINIT;	// Media Status 
//char curr_dir[SD_MAX_DIR_NAME_LENGTH];
///////////////////////////////////////////////////////////////////////////


#separate
BYTE SD_cmd(BYTE cmd, int32 address)
//////////////////////////////////////////////////////////////////////////
// SD_cmd
//
//		Send commands to the SD card via the SPI bus
//
// Entry:
//		The SD must be selected (CS must be asserted) prior to calling
//		this function
//////////////////////////////////////////////////////////////////////////
	{
	BYTE i;
	BYTE response;
	BYTE *value;

	value = &address;

	// dummy write to ensure SD/MMC in sync with SPI bus
	spi_read(0xFF);
	spi_read(cmd);
	spi_read(value[3]);
	spi_read(value[2]);
	spi_read(value[1]);
	spi_read(value[0]);
	spi_read(0x95); // valid crc for put card in SPI command (0x40)
	// invalid for others but spi mode doesn't care

	// NCR - Maximum number of cycles between command and response is 64 clock cycles (8 bytes)
	i = 0;
	response = spi_read(0xFF);
	while ((response == 0xFF) && (i < 10))
		{
		i++;
		response = spi_read(0xFF);
		}
	// Error free response should be 0x00 to acknowledge the 
	// command or 0xFF if no response was detected from the card
	return(response);
	}


#define set_BLOCKLEN SD_set_BLOCKLEN
#separate
int SD_set_BLOCKLEN( int32 size)
//////////////////////////////////////////////////////////////////////////
// int SD_set_BLOCKLEN( int32 size)
//
//		Set the media block length
//
// Entry:
//		size in the range of 1 to 512
//////////////////////////////////////////////////////////////////////////
	{
	switch (SD_cmd(SD_CMD_SET_BLOCKLEN, size))
		{	
		case 0x00 : // done:
			block_size=size; //// assign global block size
			return(TRUE);

		case 0x40 : // invalid block size request
			// Parameter Rejected
			return(FALSE);

		default :
			// Unexpected response from SET_BLOCKLEN
			return(FALSE);
		}
	}


#define MaxReceiveDataTimeout 10000
BYTE SD_receive_data(BYTE *ptr, int32 size) 
///////////////////////////////////////////////////////////////////////////
//	BYTE SD_receive_data(BYTE *ptr, int32 size) 
//
//	Read data block from Card to memory
//	Maximum block access time = 100ms
//
// Entry
//		Ensure Memory Card is deselected before calling
//		Read class command issued to card and acknowledged
//
//	Exit
//		Returns 0 on success,
//
///////////////////////////////////////////////////////////////////////////
	{
	WORD i;
	BYTE response;

 	// poll for start token
	response = spi_read(0xFF);
	for(i=0; (i < MaxReceiveDataTimeout) && (response == 0xFF); i++)
		{
		delay_us(10);
		response = spi_read(0xFF); 
		}

	// start token?
	if (response != 0xFE)
		{
		if (!response)
			response = 0xFE;
		return(response);
		}

	// found start token, read the data
	for (i=0; i < size; i++) 
		ptr[i]=spi_read(0xFF);

	// Discard the CRC
	spi_read(0xFF);
	spi_read(0xFF);

	// clear the card
	spi_read(0xFF);
	return(0);
	}


// Wait for card ready 
BYTE wait_ready (void)
	{
	BYTE Response;
	WORD Timer;

	Timer = 50000;			// Maximum wait for ready in timeout of 500ms 
	spi_read(0xFF);
	do
		{
		delay_us(10);
		Response = spi_read(0xFF);
		Timer--;
		}
	while ((Response != 0xFF) && Timer)
		;
	return (Response);
	}


#ifndef _READONLY
#separate
BOOLEAN SD_write_data(BYTE *ptr, BYTE token) 
///////////////////////////////////////////////////////////////////////////
//	BOOLEAN SD_write_data(BYTE *ptr, BYTE token) 
//
//	Write a data block from memory to the Card
//	Maximum block access time = 100ms
//
// Entry
//		Ensure Memory Card is deselected before calling
//		Write class command issued to card and acknowledged
//
//	Exit
//		Returns TRUE on success,
//
///////////////////////////////////////////////////////////////////////////
	{
	BYTE Response;
	WORD WriteCount = 512;

	if (wait_ready() != 0xFF) 
		return (FALSE);

	spi_write(token);					// transmit data token
	if (token != 0xFD)
		{
		// here if a data token	
		while (WriteCount--)	 		// transmit the 512 byte data block tothe card
			spi_write(*ptr++);

		spi_write(0xFF);				// CRC (not used)
		spi_write(0xFF);				// Dummy clocks to force card to process the command
		Response = spi_read(0xFF);		// Receive data response
 
		for( WriteCount=0; WriteCount < 10000; WriteCount++)
			{
			delay_us(10);
			Response = spi_read(0xFF);	// digest prior operation
			if (Response !=0x00)
				break;
			}
		}
	return(TRUE);
	}



#separate
DRESULT disk_write(BYTE *Buffer, DWORD SectorNumber, BYTE SectorCount)
///////////////////////////////////////////////////////////////////////////
//	disk_write()
//
//	Writes SectorCount Sectors to the SD Card starting at the address
//	SectorNumber
//
// Entry
//  Buffer			    Pointer to the write buffer
//  SectorNumber		Sector number to write to
//  SectorCount     	Number of sectors to write (SHOULD BE 1)
///////////////////////////////////////////////////////////////////////////
	{
	if (Media_Status & STA_NOINIT) 
		return (RES_NOTRDY);

	if (Media_Status & STA_PROTECT)
		return (RES_WRPRT);

	if (!SectorCount)
		return (RES_PARERR);


	SelectSD;
	SectorNumber *= 512;		// LBA --> byte address 

	if (SectorCount == 1)	// Single block write 
		{
		if (SD_cmd(SD_CMD_WRITE_BLOCK, SectorNumber) == 0)
			if (SD_write_data(Buffer, 0xFE))
				SectorCount = 0;
		}
	else 
		{	// Multiple block write 
		if (SD_cmd(SD_CMD_WRITE_MULTIBLOCK, SectorNumber) == 0) 
			{
			do 
				{
				if (!SD_write_data(Buffer, 0xFC)) 
					break;
				Buffer += 512;
				} while (--SectorCount);

			if (!SD_write_data(0, 0xFD))	// STOP_TRAN token 
				SectorCount = 1;
			}
		}

	DeselectSD;
	spi_read(0xFF);
	return SectorCount ? RES_ERROR : RES_OK;
}
#endif





#separate
DRESULT disk_read (BYTE* Buffer, DWORD SectorNumber, BYTE SectorCount)
///////////////////////////////////////////////////////////////////////////
//	disk_read()
//
//	Reads SectorCount Sectors from the SD Card starting at the address
//	SectorNumber
//
// Entry
//  Buffer			    Pointer to the read buffer
//  SectorNumber		Sector number to read from
//  SectorCount     	Number of sectors to read (SHOULD BE 1)
///////////////////////////////////////////////////////////////////////////
	{
	if (Media_Status & STA_NOINIT) 
		return (RES_NOTRDY);

	// check sector count is valid
	if ((SectorCount > MaxSectorCount) || !SectorCount)
		return(RES_PARERR);

	// set the block size
	SelectSD;
	if (!SD_set_BLOCKLEN(SD_BlockSize))
		{
		// Cannot set block length;
		DeselectSD;
		return(RES_ERROR);
		}

	if (SectorCount == 1)
		{
		// read block command
		if(SD_cmd(SD_CMD_READ_BLOCK, SectorNumber * SD_BlockSize))
			{
			// Read_Block Error: couldn't set the read address
			DeselectSD;
			return(RES_PARERR);
			}

		if (SD_receive_data(Buffer, SD_BlockSize))
			{
			DeselectSD;
			return(RES_ERROR);
			}
		}
	else
		{
		// here to transfer multiple blocks
		// send multi block read command
		if(SD_cmd(SD_CMD_READ_MULTIBLOCK, SectorNumber * SD_BlockSize))
			{
			// Read_Block Error: couldn't set the read address
			DeselectSD;
			return(RES_PARERR);
			}

		do
			{		
			if (SD_receive_data(Buffer, SD_BlockSize))
				{
				DeselectSD;
				return(RES_ERROR);
				}

			// Update the buffer pointer
			Buffer += SD_BlockSize;
			} while (--SectorCount);
		}

	// finished sucessfully
	DeselectSD;
	return(RES_OK);
	}


#separate
DSTATUS disk_shutdown(void)
///////////////////////////////////////////////////////////////////////////
//	disk_shutdown()
//
//	Deselects the drive and sets the Media_Status to STA_NOINIT
//
///////////////////////////////////////////////////////////////////////////
	{
	DeselectSD;
	Media_Status = STA_NOINIT;
	return(Media_Status);
	}


#separate
DSTATUS disk_status(void)
///////////////////////////////////////////////////////////////////////////
//	disk_status()
//
//	Tests and returns the status of the Media
//
///////////////////////////////////////////////////////////////////////////
	{
	// test for presence of the card
	//if (bit_test(SD_CD_Pin))
	if(0)
		{
		// no card, go clean up
		Media_Status = disk_shutdown() | STA_NODISK;
		return(Media_Status);
		}
	else
		// card found
		Media_Status &= ~STA_NODISK;

	// check write protect status
	#ifdef SD_WP_Pin
		if (bit_test(SD_WP_Pin))
			Media_Status |= STA_PROTECT;
		else
	#endif

		Media_Status &= ~STA_PROTECT;

	return(Media_Status);
	}


#separate
DSTATUS disk_initialize(void)
///////////////////////////////////////////////////////////////////////////
//	disk_initialize()
//
//	Initialize the SPI bus and Memory card internal logic
//
///////////////////////////////////////////////////////////////////////////
	{
	int16 i;
	BYTE response;
	DSTATUS SDCardStatus = 0;

	// initialise the card type
	Card = None_Present;

	DeselectSD;
	delay(10000);

	// SPI Mode 3
	// setup_spi(SPI_MASTER | SPI_H_TO_L | SPI_CLK_DIV_4 | SPI_XMIT_L_TO_H);

	// prepare to flush the SPI bus for the MMC and SD Memory Cards. 
	// sets the SPI bus speed low and initiates 80 SPI clock pulses
	// SPI Mode 0
	setup_spi(SPI_MASTER | SPI_L_TO_H | SPI_CLK_DIV_64 | SPI_XMIT_L_TO_H);

	// bit_set(SSPSTAT,7);			// @@@ sample end
 	// bit_clear(SSPSTAT,7);			// @@@ sample middle
	clear_interrupt(INT_SSP);

	// flush the SPI bus
	for(i=0; i<10; i++)  	// generate 80 clocks to get SD/MMC card ready
		spi_read(0xFF);

	// test if the card is present
	//printf("Testing for presence of the card\r\n");
	//if (bit_test(SD_CD_Pin))
	//	return(STA_NODISK | STA_NOINIT);

	//printf("Testing write protect status of the card\r\n");
	// get the write protect status of the card
	// active low indicates the card is write protected
	#ifdef SD_WP_Pin
		if (bit_test(SD_WP_Pin))
			SDCardStatus = STA_PROTECT;
	#endif

	// put the card into the idle state
	SelectSD;
	do
		{
		response = SD_cmd(SD_CMD_GO_IDLE_STATE,0); 
		if ((response != 0x01) && (response != 0))
			{
			delay_us(10);
			i++;
			}
		}
	while (((response != 0x01) && (response != 0)) && (i < 50000));

	if ((response != 0x01) && (response != 0))
		{
		SDCardStatus |= STA_NOINIT;
		goto Exit_disk_initialize;
		}


	// Wait for the card to become ready
	// Maximum 500ms CMD1 (SD_CMD_SEND_OP_COND) to Ready
	i = 0;
	do
		{
		response = SD_cmd(SD_CMD_SEND_OP_COND,0);	
		if (response != 0x00 )
			delay_us(10);
		i++;
		}
	while ((!(response==0x00)) && (i < 50000)); 

	if(response)
		{
		SDCardStatus |= STA_NOINIT;
		goto Exit_disk_initialize;
		}

	// send an SD specific application command 
	// and see how the card responds
	printf("Attempting card type discovery by sending SD specific application command\r\n");
	#asm Nop #endasm
	response = SD_cmd(SD_CMD_APPL_CMD,0);
	if (response)
		{
		// if any response then the card cannot support application commands
		// and therefore cannot be an SD card
		Card = MMC;
		}
	else
		{
		// send SD_SEND_OP_COND
		response = SD_cmd(SD_CMD_SD_SEND_OP_COND,0);
		if (!response)
			Card = SD;
		else
			{
			// Invalid response to SD Application command - trying MMC init sequence
			Card = MMC;

			// reinitialise as MMC card
			response = SD_cmd(SD_CMD_GO_IDLE_STATE,0); 
			if ((response !=0x01) && (response != 0))
				{
				// Card reset failure - aborting SD card initialization;
				SDCardStatus |= STA_NOINIT;
				goto Exit_disk_initialize;
				}

			// Wait for the card to become ready
			// Maximum 500ms CMD1 (SD_CMD_SEND_OP_COND) to Ready
			i = 0;
			do
				{
				response = SD_cmd(SD_CMD_SEND_OP_COND,0);	
				if (response != 0x00 )
					delay_us(10);
				i++;
				}
			while ((!(response==0x00)) && (i < 50000)); 

			if(response)
				{
				SDCardStatus |= STA_NOINIT;
				goto Exit_disk_initialize;
				}
			}
		}

	// Completed card identification
	switch (Card)
		{
		case MMC :fc
			printf("MMC Card found\r\n");
			break;

		case SD :
			printf("SD Card found\r\n");
			break;

		default :
			printf("Card Type Discovery Error - should never get here\r\n");
			SDCardStatus |= STA_NOINIT;
			goto Exit_disk_initialize;
		}

	printf("Card reset success - Cmd to Ready count = %lu\r\n", i);
	// set the SPI bus speed to high
	// SPI Mode 3
	// setup_spi(SPI_MASTER | SPI_H_TO_L | SPI_CLK_DIV_4 | SPI_XMIT_L_TO_H);

	// SPI Mode 0
	setup_spi(SPI_MASTER | SPI_L_TO_H | SPI_CLK_DIV_4 | SPI_XMIT_L_TO_H);

	// bit_set(SSPSTAT,7);			// @@@ sample end
 	// bit_clear(SSPSTAT,7);			// @@@ sample middle
	clear_interrupt(INT_SSP);

	// Wait for the card to become ready 
	i = 0;
	do
		{
		response = SD_cmd(SD_CMD_SEND_OP_COND,0);	
		if (response != 0x00 )
			delay_us(10);
		i++;
		}
	while ((!(response==0x00)) && (i < 50000));
	
	if (response != 0x00) 
		{
		// printf(" Card activate failure. Card Response = %X\r\n", Status);
		SDCardStatus |= STA_NOINIT;
		goto Exit_disk_initialize;
		}

	printf(" Card activate success on attempt %lu\r\n",i);

Exit_disk_initialize:
	DeselectSD;
	return(SDCardStatus);
	}




#separate
DRESULT disk_ioctl (BYTE ctrl, void *buff)
///////////////////////////////////////////////////////////////////////////
//	disk_ioctl
//
//	Low Level SD function
//
//	Entry
//		ctrl		control code
//		buff		pointer to send / receive block
//
///////////////////////////////////////////////////////////////////////////
	{
	DRESULT Response;
	BYTE i, csd[16], *ptr;
	WORD csm, csize;

	ptr = buff;
	if (Media_Status & STA_NOINIT) 
		return (RES_NOTRDY);

	SelectSD;

	Response = RES_ERROR;
	switch (ctrl) {
		case GET_SECTORS :	// Get number of sectors on the disk (unsigned long) 
			if (SD_cmd(SD_CMD_SEND_CSD,0x00000000) == 0)
				if (SD_receive_data(ptr, (int32) 16) == 0)
					{
					// Calculate disk size 
					csm = 1 << (((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2);
					csize = ((WORD)(csd[8] & 3) >> 6) + (WORD)(csd[7] << 2) + ((WORD)(csd[6] & 3) << 10) + 1;
					*(DWORD*)ptr = (DWORD)csize * csm;
					Response = RES_OK;
					}

		case SD_GET_CSD :	// Receive CSD as a data block (16 bytes) 
			if (SD_cmd(SD_CMD_SEND_CSD,0x00000000) == 0)
				if (SD_receive_data(ptr, (int32) 16) == 0)
					Response = RES_OK;
			break;

		case SD_GET_CID :	// Receive CID as a data block (16 bytes) 
			if (SD_cmd(SD_CMD_SEND_CID,0x00000000) == 0)
				if (SD_receive_data(ptr, (int32) 16) == 0)
					Response = RES_OK;
			break;

		case SD_GET_OCR :	// Receive OCR as an R3 resp (4 bytes) 
			if (SD_cmd(SD_CMD_SEND_OCR, 0) == 0) {	// READ_OCR 
				for (i = 0; i < 4; i++)
					*ptr++ = spi_read(0xFF);
				Response = RES_OK;
			}
			break;

		default:
			Response = RES_PARERR;
	}
	DeselectSD;	
	spi_read(0xFF);			// Idle (Release DO) 
	return (Response);
}
#define _DISKIF
#endif
