//Keypad Lookups
int const Row_Pattern[] = {
0b10010110, //decode for row1
0b10010101, //decode for row2
0b10010011  //decode for row3
};

int const Row3_decoder[] = {
0x01,   //inc sec          key 1
0x03,   //inc hundredths   key 3
0x02,   //inc tenths       key 2
0xff    //dummy key
};

int const Row2_decoder[] = {
0x05,   //dec tenths       key 5
0x06,   //dec hundth       key 6
0xff,   //dummy key
0x04    //dec sec          key 4
};

int const Row1_decoder[] = {
0x09,   //dec channel      key 9
0xff,   //dummy key
0x08,   //save key         key 8
0x07,   //inc channel      key 7
};

int Scan_Keypad(void)
{
	int row_data = 0;
	int row = 3;

while(row > 0)
{	
	output_low(PIN_C0);						                //clear 3 bits for keypad
	output_low(PIN_C1);		
	output_low(PIN_C2);	
	
	row--;									                //decrement row counter
	set_tris_c(Row_Pattern[row]);			                //set 1 keypad row low
	delay_us(5);
										                    //read the other rows
	row_data = port_c & 0b00000111;							//mask off the 3 msb bits of the row data. so we can compare it.
	if(row_data != (Row_Pattern[row] & 0b00000111))			//does output pattern = the read data? If yes this indicates that no key was pressed
	{
		Delay(2000);                                 			//change delay_ms to a homemade delay 
		row_data = port_c & 0b00000111;						//function that includes if(Timer_Started)Timer();
		if(row_data != (Row_Pattern[row] & 0b00000111))		//If key pressed is still down after 20msec then use that keypress
		{
			if(bit_test(row_data, 0)) row_data = 1;
			else if(bit_test(row_data, 1)) row_data = 2;
			else if(bit_test(row_data, 2)) row_data = 3;
			else row_data = 0; 	
			switch(row)
			{
				case 2: key = Row3_Decoder[row_data];
				break;
				case 1: key = Row2_Decoder[row_data];
				break;
				case 0:	key = Row1_Decoder[row_data];
				break;
			}
			return(key);		
		}		
	}
}
return(0xff);
}

void Decode_Keypress(int key_pressed)
	{
	Backlight_On();
	switch(key_pressed)
		{
		case 1: Menu_Up_Button();	
		break;		  // Function of Key 1
		case 2:	Menu_Down_Button();	
		break;		  // Function of Key 2
		case 3:	Ch_Up_Button();	
		break;		  // Function of Key 3
		case 4:	Ch_Down_Button();		
		break;		  // Function of Key 4
		case 5:	F1_Button();	
		break;		  // Function of Key 5
		case 6:	F2_Button();	
		break;		  // Function of Key 6
		case 7:	F3_Button();
		break;		  // Function of Key 7
		case 8:	Enter_Button();			
		break;		  // Function of Key 8 
		case 9:	Home_Button();	  
		break;		  // Function of Key 9 
		}
	return;
	}





