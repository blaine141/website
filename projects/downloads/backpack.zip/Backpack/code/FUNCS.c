void delay(int32 us)
{
	while(us>255)
	{
		delay_us(255);
		us-=255;
	}		
	delay_us(us);
}	
void Menu_Up_Button()
{
	switch(Current_Display_Mode)
	{
		case MENU:
			if(Main_Menu_Counter--==0)Main_Menu_Counter=Main_Menu_Max;
			Update_Main_Menu();
			break;
		case SETTINGS_SCREEN:
			if(Settings_Item--==0)Settings_Item=7;
			Update_Settings();
			break;
	}
}
void Menu_Down_Button()
{
	switch(Current_Display_Mode)
	{
		case MENU:
			if(Main_Menu_Counter++==Main_Menu_Max)Main_Menu_Counter=0;
			Update_Main_Menu();
			break;
		case SETTINGS_SCREEN:
			if(Settings_Item++==7)Settings_Item=0;
			Update_Settings();
			break;
	}
}			
void Ch_Up_Button()
{		
	switch(Current_Display_Mode)
	{
		case MENU:
			switch(Main_Menu_Counter)
			{
				case SIGNALS:
					Signals_Status = Signals_Status=(Signals_Status-1)%4;
					break;
				case ROUTER:
					Router_Status = !Router_Status;
					break;
				case OUTLET:
					Outlet_Status = !Outlet_Status;
					break;	
				case LIGHTS:
					if(Lights_Status--==0)Lights_Status=3;
					break;
				case FLASH_STYLE:
					if(Current_Style--==0)Current_style=1;
					break;
			}	
			Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
			Update_Main_Menu();
			break;
		case SETTINGS_SCREEN:
			switch(Settings_Item)
			{
				case R:
					if(Red++==50)Red=0;
					write_eeprom(RED_ADDRESS,Red);
					break;	
				case G:
					if(Green++==50)Green=0;
					write_eeprom(GREEN_ADDRESS,Green);
					break;
				case B:
					if(Blue++==50)Blue=0;
					write_eeprom(BLUE_ADDRESS,Blue);
					break;
				case SIGNALS_SETTING:
					write_eeprom(SIGNALS_STATUS_ADDRESS,(read_eeprom(SIGNALS_STATUS_ADDRESS)-1)%4);
					break;
				case OUTLET_SETTING:
					write_eeprom(OUTLET_STATUS_ADDRESS,!read_eeprom(OUTLET_STATUS_ADDRESS));
					break;
				case ROUTER_SETTING:
					write_eeprom(ROUTER_STATUS_ADDRESS,!read_eeprom(ROUTER_STATUS_ADDRESS));
					break;
				case SIGNAL_T:
					write_eeprom(SIGNAL_DELAY_ADDRESS ,++signal_delay);
					break;
				case OVERHEAT_TEMP_SETTING:
					write_eeprom(OVERHEAT_TEMP_ADDRESS+1,(++overheating_temp)/255);
					write_eeprom(OVERHEAT_TEMP_ADDRESS,(int)overheating_temp);
					break;
			}	
			Update_Settings();
			break;
		case GAME_SCREEN:
			if(trys!=0)
				guess = (guess+1)%10;
			Update_Game();
			break;
	}		
}       
void Ch_Down_Button()
{	
	switch(Current_Display_Mode)
	{
		case MENU:
			switch(Main_Menu_Counter)
			{
				case SIGNALS:
					Signals_Status = Signals_Status=(Signals_Status+1)%4;
					break;
				case ROUTER:
					Router_Status = !Router_Status;
					break;
				case OUTLET:
					Outlet_Status = !Outlet_Status;
					break;	
				case LIGHTS:
					if(Lights_Status++==3)Lights_Status=0;
					break;
				case FLASH_STYLE:
					if(Current_Style++==1)Current_style=0;
					break;
			}	
			Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
			Update_Main_Menu();
			break;
		case SETTINGS_SCREEN:
			switch(Settings_Item)
			{
				case R:
					if(Red--==0)Red=50;
					write_eeprom(RED_ADDRESS,Red);
					break;	
				case G:
					if(Green--==0)Green=50;
					write_eeprom(GREEN_ADDRESS,Green);
					break;
				case B:
					if(Blue--==0)Blue=50;
					write_eeprom(BLUE_ADDRESS,Blue);
					break;
				case SIGNALS_SETTING:
					write_eeprom(SIGNALS_STATUS_ADDRESS,(read_eeprom(SIGNALS_STATUS_ADDRESS)+1)%4);
					break;
				case OUTLET_SETTING:
					write_eeprom(OUTLET_STATUS_ADDRESS,!read_eeprom(OUTLET_STATUS_ADDRESS));
					break;
				case ROUTER_SETTING:
					write_eeprom(ROUTER_STATUS_ADDRESS,!read_eeprom(ROUTER_STATUS_ADDRESS));
					break;
				case SIGNAL_T:
					write_eeprom(SIGNAL_DELAY_ADDRESS ,--signal_delay);
					break;
				case OVERHEAT_TEMP_SETTING:
					if(overheating_temp>current_temp+75)
						write_eeprom(OVERHEAT_TEMP_ADDRESS,--overheating_temp);
					break;
			}	
			Update_Settings();
			break;
		case GAME_SCREEN:
			if(trys!=0)
				guess = (guess+9)%10;
			Update_Game();
			break;
	}		
}	
void F1_Button() //voltage
{
	clearLCD();
	sprintf(message,"    Voltage:");
	displayline(1,message);	
	sprintf(message,"     %2.2gV",current_voltage);
	displayline(2,message);	
	popup_delay_time = 3000;
} 
void F2_Button() //temp
{
	clearLCD();
	sprintf(message,"  Battery Temp");
	displayline(1,message);
	float calculated_temp = 0;
	calculated_temp = (float)current_temp / 4;  //calculate average of 4 samples
	calculated_temp = calculated_temp / 1023*900-459.67;
	sprintf(message,"     %1.1g%cF",calculated_temp,0b11011111);
	displayline(2,message);	
	popup_delay_time = 3000;
}
void F3_Button()
{
	clearLCD();
	sprintf(message,"    Current");
	displayline(1,message);
	sprintf(message,"%1.1gmA %4.1gmAh",current,mah);
	displayline(2,message);	
	popup_delay_time = 3000;
}
void Enter_Button()
{
	strcpy(message,"");
	switch(Current_Display_Mode)
	{
		case MENU:
			if(Main_Menu_Counter==SETTINGS)
			{
				Current_Display_Mode = SETTINGS_SCREEN;
				Settings_Item=0;
				Update_Settings();	
			}		
			if(Main_Menu_Counter==GAME)
			{
				Current_Display_Mode = GAME_SCREEN;
				trys = 3;
				last_guess = 255;
				Update_game();
			}		
			break;
		case SETTINGS_SCREEN:
			switch(Settings_Item)
			{
				case INVERT_SIGNALS_SETTING:
					write_eeprom(INVERT_SIGNAL_ADDRESS ,!read_eeprom(INVERT_SIGNAL_ADDRESS ));
					Invert_Signals=!Invert_Signals;
					Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
					output_low(RIGHT_LIGHT);
					output_low(LEFT_LIGHT);
					break;	
			}	
		case GAME_SCREEN:
			if(trys!=0)
			{
				last_guess = guess; 
				trys--;
				Update_Game();
			}
			break;
	}	
}
void Home_Button()
{
   Update_Main_Menu();
   Current_Display_Mode = MENU;
   blinking=0;
   return;
}
void Update_Devices(int router,int outlet,int signals)
{
	if(Router!=0)
		output_high(ROUTER_PIN);
	else
		output_low(ROUTER_PIN);
	if(Outlet)
		output_high(OUTLET_PIN);
	else
		output_low(OUTLET_PIN);
	Signals_Enabled=signals;
	if(Invert_Signals)
	{
		right_light_i=LEFT_LIGHT;
		left_light_i=RIGHT_LIGHT;
	}
	else
	{
		right_light_i=RIGHT_LIGHT;
		left_light_i=LEFT_LIGHT;
	}	
	if(Lights_Status==2||Lights_Status==3)
	{
		ButtonStateR=1;
		currentReadingR=1;
	}
	else
	{
		if(!currentReadingR)
		{
			output_low(right_light_i);
			ButtonStateR=0;
		}
	}
	if(Lights_Status==1||Lights_Status==3)
	{
		ButtonStateL=1;
		currentReadingL=1;
	}
	else
	{
		if(!currentReadingL)
		{
			ButtonStateL=0;
			output_low(left_light_i);
		}
	}		
}	
