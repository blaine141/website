//3 times every millisecond
#INT_TIMER2
void Backlight_Timer(void)
{
	loop_length++;
	if(popup_delay_time!=0)
		popup_delay_time--;
	clear_interrupt(INT_TIMER2);
	Backlight_Timer_Hundredths++;
	if(Backlight_Timer_Hundredths == 30)
	{
		timeCounterR++;
	   	timeCounterL++;
	   	timeHeldR++;
	   	timeHeldL++;
	   	if (timeCounterR > (int16)signal_delay+signal_delay)
	   	{ 
		   	if (buttonStateR&&current_style==0)
	      		output_low(Right_Light_i);
	      	timeCounterR = 0;
	   	} else if (timeCounterR > signal_delay) {
	      	if (buttonStateR&&(signals_enabled==2||signals_enabled==3))
	         	output_high(RIGHT_LIGHT_i);
	   	}
	   	if (timeCounterL > (int16)signal_delay+signal_delay)
	   	{ 
		   	if (buttonStateL&&current_style==0)
		      	output_low(LEFT_LIGHT_i);
	      	timeCounterL = 0;
	   	} else if (timeCounterL > signal_delay) {
	      	if (buttonStateL&&(signals_enabled==1||signals_enabled==3))
	         	output_high(LEFT_LIGHT_i);
	   	}
	   	if(Backlight_Tmr == 0)
		   	Backlight_Timer_Hundredths = 0;
	}   	
	if(Backlight_Tmr != 0)
	{
		if(color_counter++==50)color_counter=0;
		Backlight_Off();
		if(color_counter<=red)output_high(RED_BACKLIGHT);
		if(color_counter<=green)output_high(GREEN_BACKLIGHT);
		if(color_counter<=blue)output_high(BLUE_BACKLIGHT);
		
		if(Backlight_Timer_Hundredths != 30) return;
		
		Backlight_Timer_Hundredths = 0;
		Backlight_Tmr--;
			
		if(Backlight_Tmr == 0 ) Backlight_off();
		return;
	}	
}
#INT_EXT1
void Bit_Recieved(void)
{
	if(receivingByte)
	{
		if(input(PIN_B5))
			bit_clear(receivedData,bitPos);
		else
			bit_set(receivedData,bitPos);	
		bitPos++;
	}
	else
		receivingByte = 1;	
			
			
		
}	