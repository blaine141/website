/******************************************************************************
    \file lcd.c
    \brief LCD driver.
    \author Deva Seetharam
    \date   1/7/2004
    \version 0.1


This file is part of the lcd driver and it defines all the function definitions.
Copyright (C) 2005 Deva Seetharam

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
USA.
******************************************************************************/


/**
 * This function displays string of characters. Any string longer
 * than 20 characters is truncated. The function also takes
 * care of rolling over.
 * @param theString - the string to be displayed.
 */


void displayLine(int line, char* theString)
{
    unsigned char i;

    if(line == 1) setLCDAddress(0x00);
		else setLCDAddress(0x40);

    i = 0;
    if (strlen(theString) > 17)
        theString[17] = 0; /* truncate the string to 17 */

    while(theString[i])
    {
        delay(2000);
        output_low(LCD_RW); /* put LCD in write mode */
        delay_us(1);
		output_high(LCD_RS); /* select data register */
        delay_us(1);
		output_high(LCD_E); /* enable lcd */
		delay_us(1);
        output_d(theString[i]);
		delay_us(1);
        output_low(LCD_E); /* disable lcd */
        i++;
    }
 }
 void displayLine_int(int line, char* theString)
{
    unsigned char i;

    if(line == 1) setLCDAddress_int(0x00);
		else setLCDAddress_int(0x40);


    while(theString[i])
    {
        delay_ms(2);
        output_low(LCD_RW); /* put LCD in write mode */
        delay_us(1);
		output_high(LCD_RS); /* select data register */
        delay_us(1);
		output_high(LCD_E); /* enable lcd */
		delay_us(1);
        output_d(theString[i]);
		delay_us(1);
        output_low(LCD_E); /* disable lcd */
        i++;
    }
 }

/**
 * This function displays a string of characters on line 2.
 * @param theString - the string to be displayed.
*/
/*
void displayLine2(char* theString)
{
    unsigned char i;
	setLCDAddress(0x40);
    i = 0;

    if (strlen(theString) > 17)
        theString[17] = 0; // truncate the string to 17 

    while(theString[i])
    {
        delay_ms(2);
        output_low(LCD_RW); // put LCD in write mode 
        delay_us(1);
		output_high(LCD_RS); // select data register 
        delay_us(1);
		output_high(LCD_E); // enable lcd 
        delay_us(1);
		output_d(theString[i]);
        delay_us(1);
		output_low(LCD_E); // disable lcd 
        i++;
    }
}
*/

void sendCommandToLCD(int cmd)
{
    output_low(LCD_RW); /* put LCD in write mode */
    delay_us(200);
	output_low(LCD_RS); /* select instruction register */
	delay_us(250);
	output_high(LCD_E); /* enable lcd */
    delay_us(250);
	output_d(cmd);
    delay_us(250);
	output_low(LCD_E); /* disable lcd */
}
void sendCommandToLCD_int(int cmd)
{
    output_low(LCD_RW); /* put LCD in write mode */
    delay_us(200);
	output_low(LCD_RS); /* select instruction register */
	delay_us(250);
	output_high(LCD_E); /* enable lcd */
    delay_us(250);
	output_d(cmd);
    delay_us(250);
	output_low(LCD_E); /* disable lcd */
}

/**
 * @desc This function initializes the Optrex LCD module 50448. 
 * To understand the sequence, pls. see the datasheet.
 * @param - none
 * @return - none
 */
  
void InitLCD()
{
  	delay(20000);  /* wait for >= 15 ms */
    sendCommandToLCD(0x30); /* function set command */
	delay(5000);  /* wait for >= 4.1 ms */
	sendCommandToLCD(0x30); /* function set command */
   	delay_us(150); /* wait for >= 100 us */
	sendCommandToLCD(0x30); /* function set command */

	//Need to add code to check the Busy flag before we move on.
	delay(20000);
	sendCommandToLCD(0x3C); /* 8-bit interface, 2 lines, 5x10 dots */
	delay(2000);
	sendCommandToLCD(display_off); /* display off */
	//Need to add code to check the Busy flag before we move on.
	delay(2000);
	sendCommandToLCD(clear_lcd); /* clear LCD */
	//Need to add code to check the Busy flag before we move on.
	delay(2000);
    sendCommandToLCD(cursor_off); /* display on and cursor off */
	//Need to add code to check the Busy flag before we move on.
	delay(2000);
    sendCommandToLCD(entry_mode); /* increment address and no display shifts */
	delay(2000);
	return;
}

/**
 * This function clears LCD.
 * @param - none
 * @return - none
 */
void clearLCD()
{
    sendCommandToLCD(0x01);
}
void clearLCD_int()
{
    sendCommandToLCD_int(0x01);
}
/**
 * This function positions the cursor to the first position of display.
 * @param - none
 * @return - none
 */
void setLCDCursorHome()
{
    sendCommandToLCD(0x02);
}	

/**
 * This function sets the current position of LCD display to the specified address.
 * @param address - display address.
 * @return - none
 */
void setLCDAddress(int address)
{
        /* To set the address DB7 must be 1 and the DB6-DB0 contain
           the address */
	delay_us(10);
    sendCommandToLCD(0x80 | (address & 0x7F));
}
void setLCDAddress_int(int address)
{
        /* To set the address DB7 must be 1 and the DB6-DB0 contain
           the address */
	delay_us(10);
    sendCommandToLCD_int(0x80 | (address & 0x7F));
}

/**
 * This function displays the given character at the specified address.
 * @param address - display address.
 * @param data - character to be displayed.
 * @return - 
 */

void setLCDCharAtAddress(int address, INT8 data)
{
    setLCDAddress(address);
    displayChar(data);
}


