/******************************************************************************
    \file lcd.h
    \brief LCD driver function declarations.
    \author Deva Seetharam
    \date   1/7/2004
    \version 0.1

This header file is part of the lcd driver.  Copyright (C) 2005 Deva
Seetharam

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
USA.
******************************************************************************/
#ifndef LCD_H
#define LCD_H
#include <global.h>
#include <datatype.h>


//Defines for the lcd
#define clear_lcd         0x01 // Clear Display                       
#define return_home       0x02 // Cursor to Home position              
#define entry_mode        0x06 // Normal entry mode                    
#define entry_mode_shift  0x07 //  with shift                         
#define system_set_8_bit  0x38 // 8 bit data mode 2 line ( 5x7 font )  
#define system_set_4_bit  0x28 // 4 bit data mode 2 line ( 5x7 font )  
#define display_on        0x0c // Switch ON Display                    
#define display_off       0x08 // Cursor plus blink                    
#define set_dd_line1      0x80 // Line 1 position 1                   
#define set_dd_line2      0xC0 // Line 2 position 1                    
#define set_dd_ram        0x80 // Line 1 position 1                    
#define write_data        0x00 // With RS = 1                          
#define cursor_on         0x0E // Switch Cursor ON                     
#define cursor_off        0x0C // Switch Cursor OFF                    
#define shift_right		  0x1F // Rotate the display to the right			
#define shift_left 		  0x18 // Rotate the display to the left

void InitLCD();
void sendCommandToLCD(INT8 command);

void clearLCD();
void setLCDCursorHome();
void setLCDAddress(UINT8 address);
void setLCDAddress_int(UINT8 address);
void setLCDCharAtAddress(UINT8 address, INT8 data);
void displayByte(INT8 data);

void displayChar(INT8 c);
#endif
