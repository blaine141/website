
void Backlight_On(void)
{
	Backlight_Tmr = BACKLIGHT_ON_TIME;
}
void Backlight_Off(void)
{
	output_low(BLUE_BACKLIGHT);
	output_low(GREEN_BACKLIGHT);
	output_low(RED_BACKLIGHT);
}
void Return_To_Display_Mode(void)
{
	switch(Current_Display_Mode)
	{
		case MENU:
			Update_Main_Menu();
			break;
		case SETTINGS_SCREEN:
			Update_Settings();
			break;
		case GAME_SCREEN:
			Update_Game();
			break;
	}
}
void Update_Main_Menu(void)
{
	clearLCD();		
	delay_us(1);
	strcpy(message, "Backpack   ");
	displayLine(1,message);
	switch(Main_Menu_Counter)
    {
    	case SIGNALS:
			sprintf(message, "  Signals: ");
			strcpy(message,strcat(message,signalEnabled[Signals_Status]));
			break;
		case ROUTER:
			sprintf(message, "  Router:    ");
			strcpy(message,strcat(message,status[Router_Status]));
			break;
		case OUTLET:
			sprintf(message, "  Outlet:    ");
			strcpy(message,strcat(message,status[Outlet_Status]));
			break;
		case GAME:
			sprintf(message, "  ~Play game    ");
			break;
		case LIGHTS:
			sprintf(message, "  Lights:  ");
			strcpy(message,strcat(message,lightStatus[Lights_Status]));
			break;
		case FLASH_STYLE:
			sprintf(message, "  Style:   ");
			strcpy(message,strcat(message,Flash_Types[Current_Style]));
			break;
		case SETTINGS:
			sprintf(message, "  ~Settings      ");
	}
	displayLine(2,message); 
}	
void Update_Settings(void)
{
	switch(Settings_Item)
	{
		case R:
			strcpy(message,"Red Intensity:  ");
			displayLine(1,message);
			sprintf(message,"  %u / 50       ",red);
			displayLine(2,message);
			break;
		case G:
			strcpy(message,"Green Intensity:");
			displayLine(1,message);
			sprintf(message,"  %u / 50       ",green);
			displayLine(2,message);
			break;
		case B:
			strcpy(message,"Blue Intensity: ");
			displayLine(1,message);
			sprintf(message,"  %u / 50       ",blue);
			displayLine(2,message);
			break;
		case SIGNALS_SETTING:
			strcpy(message,"Signals:        ");
			displayLine(1,message);
			sprintf(message,"  On Start~%s",signalEnabled[read_eeprom(SIGNALS_STATUS_ADDRESS)]);
			displayLine(2,message);
			break;
		case OUTLET_SETTING:
			strcpy(message,"Outlet:         ");
			displayLine(1,message);
			sprintf(message,"  On Start~  %s",status[read_eeprom(OUTLET_STATUS_ADDRESS)]);
			displayLine(2,message);
			break;
		case ROUTER_SETTING:
			strcpy(message,"Router:         ");
			displayLine(1,message);
			sprintf(message,"  On Start~  %s",status[read_eeprom(ROUTER_STATUS_ADDRESS)]);
			displayLine(2,message);
			break;
		case INVERT_SIGNALS_SETTING:
			strcpy(message,"Invert Signals: ");
			displayLine(1,message);
			sprintf(message,"  ~Press Enter  ");
			displayLine(2,message);
			break;
		case SIGNAL_T:
			strcpy(message,"Signal Delay:   ");
			displayLine(1,message);
			sprintf(message,"  %u            ",Signal_Delay);
			displayLine(2,message);
			break;
		case OVERHEAT_TEMP_SETTING:
			strcpy(message,"Overheat Temp:  ");
			displayLine(1,message);
			sprintf(message,"  %1.1g            ",(float)overheating_temp/4092*900-459.67);
			displayLine(2,message);
	}	
}	
void Update_game(void)
{
	if(last_guess==guess)
	{
		if (guess==game_num)
		{
			sprintf(message,"   You got it   ");
			displayLine(1,message);
			sprintf(message,"        %u       ",guess);
			displayLine(2,message);	
			trys = 0;
			return;
		}	
		if(trys==0&&last_guess!=game_num)
		{
			sprintf(message, "    You Lose    ");
			displayLine(1,message);
			sprintf(message, "     Ans: %u     ", game_num);
			displayLine(2,message);
			return;
		}
		if(guess<game_num)
			sprintf(message,"Trys: %u  Bigger",trys);
		else 
			sprintf(message,"Trys: %u Smaller",trys);
		displayLine(1,message);
		
	} else {
		
		sprintf(message,"Trys: %u         ",trys);
		displayLine(1,message);
		if(last_guess==255)
			game_num = rand()%10;
	
	}
	sprintf(message,"        %u       ",guess);
	displayLine(2,message);	
}	