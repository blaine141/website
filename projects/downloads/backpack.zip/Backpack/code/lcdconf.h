/******************************************************************************
    \file lcdconf.h
    \brief LCD Configuration Details.
    \author Deva Seetharam
    \date   1/7/2004
    \version 0.1

This header file is part of the lcd driver.
Copyright (C) 2005 Deva Seetharam

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or (at
your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
******************************************************************************/
#ifndef LCDCONF_H
#define LCDCONF_H

#include <global.h>

/* This driver is written for the following configuration: 
   Data pins of LCD are connected to PORT A.
   Control pins of LCD are connected to pins A0 A1 and A2.

   If different ports are used, the following pin definitions must be
   changed.
*/


#use fast_io (A)

#define LCD_RS     		PIN_E2
#define LCD_RW    		PIN_B0
#define LCD_E      		PIN_A5

#use fast_io (C)
#define LCD_DB0         PIN_D0
#define LCD_DB1         PIN_D1
#define LCD_DB2         PIN_D2
#define LCD_DB3         PIN_D3
#define LCD_DB4         PIN_D4
#define LCD_DB5         PIN_D5
#define LCD_DB6         PIN_D6
#define LCD_DB7         PIN_D7


#endif
