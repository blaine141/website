
#include <18F4685.h>

#device ADC=10 //for 18F4620 devices 
#define USE_FAT_LITE // configure the filesystem for FAT Lite operation
#include <lcdconf.h>
#include <lcd.h>
#include <EEPROM.H>

#use delay(clock=16384000)

//PRODUCTION FUSES
//#fuses HS,NOWDT,PROTECT,NOLVP,BROWNOUT,NOWRT,PUT,NOCPD,NOPBADEN,NODEBUG

//DEBUG FUSES
#fuses HS,NOWDT,NOPROTECT,NOLVP,BROWNOUT,NOWRT,PUT,NOCPD,DEBUG

//#include <IO_PINS.H>

#define BACKLIGHT_ON_TIME 1000

#define BLUE_BACKLIGHT    	PIN_B4
#define RED_BACKLIGHT    	PIN_E0
#define GREEN_BACKLIGHT    	PIN_B3
#define ROUTER_PIN 			PIN_A4
#define OUTLET_PIN 			PIN_C6
#define RIGHT_BUTTON 		PIN_E1
#define LEFT_BUTTON			PIN_C4
#define RIGHT_LIGHT			PIN_B1
#define LEFT_LIGHT			PIN_A3

//These screens are used to determine how to edit the data displayed on the screen
enum Valid_Screens {MENU, SETTINGS_SCREEN, GAME_SCREEN};
enum Main_Menu_Items {SIGNALS, OUTLET, LIGHTS, GAME, FLASH_STYLE, SETTINGS, ROUTER};
enum Settings_Items {R, G, B, SIGNALS_SETTING, OUTLET_SETTING, INVERT_SIGNALS_SETTING, SIGNAL_T, OVERHEAT_TEMP_SETTING, ROUTER_SETTING};
int Current_Display_Mode;

//integer array to hold thnle display value so I can do digit inc and dec.
char status[2][4] = {"OFF"," ON"};
char signalEnabled[4][6] = {"  OFF"," LEFT","RIGHT","   ON"};
char lightStatus[4][6] = {"  OFF"," LEFT","RIGHT"," BOTH"};
char Flash_Types[2][6] = {"FLASH"," HOLD"};
int Current_Style=0;
int Lights_Status = 0;
int right_light_i = RIGHT_LIGHT;
int left_light_i = LEFT_LIGHT;
int red = 5; //max 50
int green = 50;
int blue = 40;
int color_counter=0;
int i = 0;
int key = 0;
int key_hit = 0;
int for_counter;
int Main_Menu_Counter = 0;
int Main_Menu_Max = 5;
int Settings_Item = 0;
int Signals_Status = 0;
int Router_Status = 0;
int Outlet_Status = 0;
int Invert_Signals;
int Signal_Delay;
int Signals_Enabled=0;
int overheating=0;
int last_overheating=0;
int overheating_stabalizer=0;
int overheating_temp_display_delay=0;
int16 overheating_temp=2545;
float current_voltage=0;
float current=0;
int32 current_temp=0;
int16 last_popup_delay = 0;
int16 popup_delay_time = 0;
int charged = 0;
int receivingByte = 0;
int bitPos = 0;
int receivedData = 0;

int loop_length=0;
float mah=0.1;
int trys = 3;
int guess = 0;
int last_guess = 255;
int game_num = 0;

int16 Keyscan_Counter = 0;
int last_key = 0;
boolean blinking = false;

int32 timeCounterL = 0, timeCounterR = 0;
int lastButtonR = false, currentReadingR, buttonStateR = false, lastReadingR = false,  lastButtonL = false, currentReadingL, buttonStateL = false, lastReadingL = false;
int32 timeHeldR, timeHeldL;

//TIMER VARIABLES
int16 Backlight_Tmr = 5000; // 5 seconds is the default backlight on time
int16 Backlight_Timer_Hundredths = 0;

//char array variables "Strings"
char message[17];

//Function Declarations
void delay(int32 us);
void Update_game(void);
void Menu_Up_Button(void);
void Menu_Down_Button(void);
void Ch_Up_Button(void);
void Ch_Down_Button(void);
void F1_Button(void);
void F2_Button(void);
void F3_Button(void);
void Enter_Button(void);
void Home_Button(void);
void Decode_Keypress(int key_pressed);
int  Scan_Keypad(void);
void displayLine(int line, char* theString);
void displayLine_int(int line, char* theString);
void Update_Display_Main_Menu(void);
void Update_Main_Menu(void);
void Update_Display(void);
void Backlight_On(void);
void Backlight_Off(void);
void Update_Settings(void);
void Return_To_Display_Mode(void);
void Update_Devices(int router,int outlet,int signals);

#BYTE port_c = 0xf82
#BYTE PIR1 = 0xf9e 
#BYTE INTCON = 0xff2
#BYTE ADCON0 = 0xfc2

//include other C files for compilation
#include "FUNCS.c"
#include "LCD.c"
#include "Display.c"
#include "KEYPAD.c"
#include "INT.c"

//Main Program
void Main()
{
port_c = 0;

//clear outputs
set_tris_a(0b00010111);
set_tris_b(0b00001100);
set_tris_c(0b10110111);
set_tris_d(0b00000000);
set_tris_e(0b00001010);


output_low(BLUE_BACKLIGHT);
output_low(RED_BACKLIGHT);
output_low(GREEN_BACKLIGHT);

output_high (PIN_C6);   //set Eprom chip select hi for not selected.	

setup_timer_0 (RTCC_DIV_16|RTCC_8_BIT);      //Set prescaler to 16 for TMR0 so crystal 16.384mhz/4 = instruction clock/prescaler(16)/256 = 1/1000sec
setup_timer_1( T1_INTERNAL | T1_DIV_BY_8 );
setup_timer_2 (T2_DIV_BY_16, 85,1);       //Prescalar = 16 post scaler = 2 total scaling  = 32 = int every 1/1000sec
ext_int_edge (1, H_TO_L);
//setup_timer_3 (T3_INTERNAL | T3_DIV_BY_4);  //Timer 3 is used to monitor the RPM input pin CCP2
clear_interrupt(INT_TIMER2);
enable_interrupts(INT_TIMER2);
enable_interrupts(INT_EXT1);
enable_interrupts(GLOBAL);

setup_wdt(WDT_OFF);

setup_adc(ADC_CLOCK_INTERNAL );
setup_adc_ports(AN0_TO_AN2);
set_adc_channel(0);

// SPI Mode 0
//setup_spi(SPI_MASTER | SPI_L_TO_H | SPI_CLK_DIV_16 | SPI_XMIT_L_TO_H );
Signals_Status = read_eeprom(SIGNALS_STATUS_ADDRESS);
Router_Status = read_eeprom(ROUTER_STATUS_ADDRESS);
Outlet_Status = read_eeprom(OUTLET_STATUS_ADDRESS);
Signal_Delay = read_eeprom(SIGNAL_DELAY_ADDRESS);
Red = read_eeprom(RED_ADDRESS);
Blue = read_eeprom(BLUE_ADDRESS);
Green = read_eeprom(GREEN_ADDRESS);
Signal_Delay = read_eeprom(SIGNAL_DELAY_ADDRESS );
Invert_Signals = read_eeprom(INVERT_SIGNAL_ADDRESS);
overheating_temp = read_eeprom(OVERHEAT_TEMP_ADDRESS)+(int16)read_eeprom(OVERHEAT_TEMP_ADDRESS+1)*256;
int *pointer;
pointer=&mah;
*pointer = read_eeprom(MAH_ADDRESS);
pointer++;
*pointer = read_eeprom(MAH_ADDRESS+1);
pointer++;
*pointer = read_eeprom(MAH_ADDRESS+2);
pointer++;
*pointer = read_eeprom(MAH_ADDRESS+3);

InitLCD();
output_high(left_light_i);
output_high(Right_light_i);
output_low(PIN_B5);
Backlight_On();

strcpy(message,"  Hello Blaine  ");
displayLine(1,message);
delay(500000);

strcpy(message,"  Welcome Back  ");
displayLine(2,message);
delay(500000);//Rev 2.27


int row_data = 0;
	

if(INPUT_STATE(RIGHT_BUTTON)&& INPUT_STATE(LEFT_BUTTON)&&false)
{
	strcpy(message,"  Buttons not  ");
	displayLine(1,message);
	
	strcpy(message,"    attached  ");
	displayLine(2,message);
	while(INPUT_STATE(RIGHT_BUTTON)&& INPUT_STATE(LEFT_BUTTON))
	{
		output_low(PIN_C0);						                //clear 3 bits for keypad
		output_low(PIN_C1);		
		output_low(PIN_C2);	
										                //decrement row counter
		set_tris_c(0b10010110);			                //set 1 keypad row low
		delay_us(5);
											                    //read the other rows
		row_data = port_c & 0b00000111;							//mask off the 3 msb bits of the row data. so we can compare it.
		if(row_data != (0b10010110 & 0b00000111))			//does output pattern = the read data? If yes this indicates that no key was pressed
		{
			Delay(2000);                                 			//change delay_ms to a homemade delay 
			row_data = port_c & 0b00000111;						//function that includes if(Timer_Started)Timer();
			if(row_data != (0b10010110 & 0b00000111))		//If key pressed is still down after 20msec then use that keypress
			{
				if(bit_test(row_data, 1)) break;
			}		
		}
	}
}	
/*strcpy(message,"     Push a     ");
displayLine(1,message);

strcpy(message,"     button.    ");
displayLine(2,message);
row_data = 0;
int Right_Pressed_On_Startup = INPUT_STATE(RIGHT_BUTTON);
int Left_Pressed_On_Startup = INPUT_STATE(LEFT_BUTTON);
while(INPUT_STATE(RIGHT_BUTTON)==Right_Pressed_On_Startup&&INPUT_STATE(LEFT_BUTTON)==Left_Pressed_On_Startup)
{
	output_low(PIN_C0);						                //clear 3 bits for keypad
	output_low(PIN_C1);		
	output_low(PIN_C2);	
									                //decrement row counter
	set_tris_c(0b10010110);			                //set 1 keypad row low
	delay_us(5);
										                    //read the other rows
	row_data = port_c & 0b00000111;							//mask off the 3 msb bits of the row data. so we can compare it.
	if(row_data != (0b10010110 & 0b00000111))			//does output pattern = the read data? If yes this indicates that no key was pressed
	{
		Delay(2000);                                 			//change delay_ms to a homemade delay 
		row_data = port_c & 0b00000111;						//function that includes if(Timer_Started)Timer();
		if(row_data != (0b10010110 & 0b00000111))		//If key pressed is still down after 20msec then use that keypress
		{
			if(bit_test(row_data, 1)) break;
		}		
	}
}	

*/
Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
Current_Display_Mode = MENU;
Update_Main_Menu();

Backlight_On();

setup_adc(ADC_CLOCK_INTERNAL );
setup_adc_ports(AN0);
set_adc_channel(0);


LOOP_START:
key_hit = Scan_Keypad();
current_voltage = 0;

for(for_counter=0;for_counter<4;for_counter++)
{
   	set_adc_channel(0);
   	read_adc(ADC_START_ONLY);
	while(bit_test(ADCON0,1)){}
   	current_voltage = current_voltage + read_adc();
}
//sprintf(message,"%g   ",current_voltage);
//displayline(1,message);
current_voltage = current_voltage / 4;  //calculate average of 4 samples
current_voltage = current_voltage / 32.62; // FOR 10 BIT ad

if(current_voltage>13&&!charged)
{
	charged = 1;
	mah=0;
}	
if(current_voltage<7)
{
	int *pointer;
	pointer = &mah;
	write_eeprom(MAH_ADDRESS, *pointer);
	pointer++;
	write_eeprom(MAH_ADDRESS+1, *pointer);
	pointer++;
	write_eeprom(MAH_ADDRESS+2, *pointer);
	pointer++;
	write_eeprom(MAH_ADDRESS+3, *pointer);
}	

current_temp=0;
set_adc_channel(1);
delay(10);
output_high(PIN_B5);
for(for_counter=0;for_counter<4;for_counter++)
{
   	read_adc(ADC_START_ONLY);
	while(bit_test(ADCON0,1)){}
  	current_temp= current_temp+read_adc(ADC_READ_ONLY);
}
output_low(PIN_B5);
if(current_temp>overheating_temp)
{
	if(!overheating&&!last_overheating)
		overheating_stabalizer++;
	else
		overheating_stabalizer=0;
	if(overheating_stabalizer>200)
		overheating = 1;
}		
else if(current_temp<overheating_temp-20)
{
	if(overheating&&last_overheating)
		overheating_stabalizer++;
	else
		overheating_stabalizer=0;
	if(overheating_stabalizer>200)
		overheating = 0;
}
if(overheating&&!last_overheating)
{
	Update_Devices(0,0,0);
	clearLCD();
	Backlight_Tmr=0;
	strcpy(message,"BACKPACK TOO HOT");
	displayLine(1,message);
	float calculated_temp = 0;
	calculated_temp = (float)current_temp / 4;  //calculate average of 4 samples
	calculated_temp = calculated_temp / 1023*900-459.67;
	sprintf(message,"     %1.1g%cF",calculated_temp,0b11011111);	
	displayLine(2,message);
	output_low(GREEN_BACKLIGHT);
	output_low(BLUE_BACKLIGHT);
	output_high(RED_BACKLIGHT);
}
else if(!overheating&&last_overheating)
{
	Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
	Backlight_On();	
	Return_To_Display_Mode();
}		
last_overheating=overheating;
if(overheating)
{
	overheating_temp_display_delay++;
	if(overheating_temp_display_delay==255)
	{
		float calculated_temp = 0;
		calculated_temp = (float)current_temp / 4;  //calculate average of 4 samples
		calculated_temp = calculated_temp / 1023*900-459.67;
		sprintf(message,"     %1.1g%cF     ",calculated_temp,0b11011111);	
		displayLine(2,message);
	}
	goto Loop_Start;
}
current=0;
set_adc_channel(2);
delay(30);
for(for_counter=0;for_counter<20;for_counter++)
{
	int16 i = 0;
	while(i<103)
	{
   		read_adc(ADC_START_ONLY);
		while(bit_test(ADCON0,1)){}
  		i=read_adc(ADC_READ_ONLY);
 	} 	
 	current= current+i;	
}
current=(current/1023/20*5-.495)*5000;
mah+=current*(loop_length+1)/3000/3600;
loop_length=0;


if(popup_delay_time==0&&last_popup_delay!=0)
	Return_To_Display_Mode();
last_popup_delay=popup_delay_time;


if(receivingByte&&bitPos == 8)
{
	red = 50;
}	


currentReadingR = INPUT_STATE(RIGHT_BUTTON);
currentReadingL = INPUT_STATE(LEFT_BUTTON);
if(currentReadingR != lastReadingR)
	timeHeldR = 0;
if(currentReadingL != lastReadingL)
	timeHeldL = 0;
if(timeHeldR > 1)
    buttonStateR = currentReadingR;
if(timeHeldL > 1)
    buttonStateL = currentReadingL;
if(buttonStateR!=lastButtonR)
{
	if (!buttonStateR)
	{
		output_low(Right_Light_i);
		Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
	}
	else
		timeCounterR = signal_delay;
}
if(buttonStateL!=lastButtonL)
{
	if (!buttonStateL)
	{
		output_low(Left_Light_i);
		Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
	}	
	else
		timeCounterL = signal_delay;
}
Update_Devices(Router_Status,Outlet_Status,Signals_Status);	
lastButtonR = buttonStateR;
lastReadingR = currentReadingR;
lastButtonL = buttonStateL;
lastReadingL = currentReadingL;
//sprintf(message,"%g   ",current_temp);
//displayline(1,message);
if(key_hit == 0xff)
{
	last_key = key_hit;
	goto Loop_Start;
}

if(last_key == key_hit)
{//Same key is still pressed
	Keyscan_Counter--;
	if(!Keyscan_Counter)
	{//Counter has elapsed
		Keyscan_Counter = 30;
		goto KEY_DECODE;
	}
	goto Loop_Start;

}

FIRST_KEY_PRESS:
//This is the first time that the key was pressed.
last_key = key_hit;
Keyscan_Counter = 200;

KEY_DECODE:
Decode_Keypress(key_hit);
goto Loop_Start;

return;
}
