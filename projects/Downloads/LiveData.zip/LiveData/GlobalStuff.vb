﻿Module GlobalStuff
    Public slides() As Slide = {MatchPredictions, Title, BestClimbers, DreamAlliance, BestGear, BestFuel}
    Public slideIndex As Integer = 0 'index of slide to start with in list above
    Public TransitionLength As Integer = 2000
    Public defaultLength As Integer = 10000 'in ms
    Public defaultBackgroundColor As Color = Color.FromArgb(15, 157, 88)
    Public teams As Dictionary(Of Integer, Team) = New Dictionary(Of Integer, Team)
    Public matches As Dictionary(Of Integer, Match) = New Dictionary(Of Integer, Match)
    Public currentMatch As Integer = 1
    Public Function changeAttribute(ByVal html As String, ByVal attribute As String, ByVal value As String) As String
        Dim attrIndex As Integer = html.IndexOf(attribute)
        Dim startInner As Integer = html.IndexOf(">", attrIndex) + 1
        Dim endInner As Integer = html.IndexOf("<", startInner)
        If attrIndex < 0 Then Return html
        Return html.Substring(0, startInner) & value & html.Substring(endInner)
    End Function
End Module
