﻿Option Strict On
Imports Transitions
Imports System.IO
Imports Microsoft.VisualBasic.FileIO.TextFieldParser
Public Class Display
    Public scoutDirectory As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.MyDocuments, "Scouting")
    Dim last As List(Of Control) = New List(Of Control)
    Private Const WM_DEVICECHANGE As Integer = &H219
    Private Const DBT_DEVICEARRIVAL As Integer = &H8000
    Private Const DBT_DEVICEREMOVECOMPLETE As Integer = &H8004
    Private Const DBT_DEVTYP_VOLUME As Integer = &H2  '
    '
    'Get the information about the detected volume.
    Private Structure DEV_BROADCAST_VOLUME

        Dim Dbcv_Size As Integer

        Dim Dbcv_Devicetype As Integer

        Dim Dbcv_Reserved As Integer

        Dim Dbcv_Unitmask As Integer

        Dim Dbcv_Flags As Short

    End Structure

    Private Sub Display_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Escape Then Me.Close()
        If e.KeyCode = Keys.Right Then
            Timer1.Interval = 1
        End If
    End Sub

    Private Sub Display_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadFile()
        CreateBrowserKey()
        Timer1.Enabled = True
        slideIndex -= 1
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.Location = New Point(0, 0)
        Me.Size = SystemInformation.PrimaryMonitorSize
        Me.BackColor = DefaultBackgroundColor
        
    End Sub
    Sub nextSlide()
        Timer1.Enabled = False
        For Each obj As Control In last
            Me.Controls.Remove(obj)
            obj.Dispose()
        Next
        last.Clear()
        For Each obj As Control In Me.Controls
            last.Add(obj)
        Next
        slideIndex += 1
        If slideIndex = slides.Length Then slideIndex = 0
        Try
            slides(slideIndex).format()
        Catch
        End Try
        Me.BackColor = defaultBackgroundColor
        For Each obj As Control In slides(slideIndex).Controls
            Dim ctrl As Control = ControlFactory.CloneCtrl(obj)
            Me.Controls.Add(ctrl)
            ctrl.Location = New Point(ctrl.Location.X + Me.Width, ctrl.Location.Y)
            ctrl.Show()
        Next
        Dim trans As Transition = New Transition(New TransitionType_Acceleration(TransitionLength))
        For Each obj As Control In Me.Controls
            trans.add(obj, "Left", obj.Location.X - Me.Width)
        Next
        trans.run()
        Try
            Timer1.Interval = slides(slideIndex).length
        Catch
            Timer1.Interval = defaultLength
        End Try
        Timer1.Enabled = True
    End Sub

    Public Sub loadFile()
        teams.Clear()
        Try
            Dim afile As FileIO.TextFieldParser = New FileIO.TextFieldParser(System.IO.Path.Combine(scoutDirectory, "Outputs/Teams.csv"))
            Dim CurrentRecord As String() ' this array will hold each line of data
            afile.TextFieldType = FileIO.FieldType.Delimited
            afile.Delimiters = New String() {","}
            afile.HasFieldsEnclosedInQuotes = True
            ' parse the actual file
            Do While Not afile.EndOfData
                Try
                    CurrentRecord = afile.ReadFields
                    Dim t As Team = New Team
                    t.num = CInt(CurrentRecord(0))
                    teams.Add(CInt(CurrentRecord(0)), t)
                    t.averageFuelScore = CDbl(CurrentRecord(1))
                    t.averageFuelTime = CDbl(CurrentRecord(2))
                    t.fuelEfficiency = CDbl(CurrentRecord(3))
                    t.averageGearScore = CInt(CurrentRecord(4))
                    t.averageGearTime = CDbl(CurrentRecord(5))
                    t.gearEfficiency = CDbl(CurrentRecord(6))
                    t.climbAccuracy = CDbl(CurrentRecord(7))
                    t.averageClimbTime = CDbl(CurrentRecord(8))
                    t.averageAutoGear = CDbl(CurrentRecord(9))
                    t.crossLineAccuracy = CDbl(CurrentRecord(10))
                    t.averageAutoFuel = CDbl(CurrentRecord(11))
                Catch ex As FileIO.MalformedLineException
                    Stop
                End Try
            Loop
            afile.Close()
        Catch
        End Try
        Try
            Dim afile As FileIO.TextFieldParser = New FileIO.TextFieldParser(System.IO.Path.Combine(scoutDirectory, "Outputs/Optimization.csv"))
            Dim CurrentRecord As String() ' this array will hold each line of data
            afile.TextFieldType = FileIO.FieldType.Delimited
            afile.Delimiters = New String() {","}
            afile.HasFieldsEnclosedInQuotes = True
            ' parse the actual file
            matches.Clear()
            Do While Not afile.EndOfData
                Try
                    CurrentRecord = afile.ReadFields
                    Dim m As Match = New Match()
                    If CurrentRecord(6) = "1" Then
                        If matches.Keys.Contains(CInt(CurrentRecord(0))) Then
                            m = matches(CInt(CurrentRecord(0)))
                        Else
                            matches.Add(CInt(CurrentRecord(0)), m)
                        End If
                        If CurrentRecord(2) = "Red" Then
                            If m.rteam1 <> Nothing Then
                                If m.rteam2 <> Nothing Then
                                    m.rteam3 = CInt(CurrentRecord(1))
                                Else
                                    m.rteam2 = CInt(CurrentRecord(1))
                                End If
                            Else
                                m.rteam1 = CInt(CurrentRecord(1))
                            End If
                            m.rscore += CDbl(CurrentRecord(5))
                            m.rteleGear += CInt(CurrentRecord(3))
                            m.rscore += teams(CInt(CurrentRecord(1))).averageAutoFuel + teams(CInt(CurrentRecord(1))).crossLineAccuracy * 5 + teams(CInt(CurrentRecord(1))).climbAccuracy * 50
                            m.rautoGear += teams(CInt(CurrentRecord(1))).averageAutoGear
                        Else
                            If m.bteam1 <> Nothing Then
                                If m.bteam2 <> Nothing Then
                                    m.bteam3 = CInt(CurrentRecord(1))
                                Else
                                    m.bteam2 = CInt(CurrentRecord(1))
                                End If
                            Else
                                m.bteam1 = CInt(CurrentRecord(1))
                            End If
                            m.bscore += CDbl(CurrentRecord(5))
                            m.bteleGear += CInt(CurrentRecord(3))
                            m.bscore += teams(CInt(CurrentRecord(1))).averageAutoFuel + teams(CInt(CurrentRecord(1))).crossLineAccuracy * 5 + teams(CInt(CurrentRecord(1))).climbAccuracy * 50
                            m.bautoGear += teams(CInt(CurrentRecord(1))).averageAutoGear
                        End If
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Loop
            afile.Close()
        Catch
        End Try
        For Each m As Match In matches.Values
            m.bscore += 40
            If m.bautoGear > 2.5 Then
                m.bscore += 40
            ElseIf m.bautoGear >= 1 Then
                m.bscore += 20
            End If
            If m.bautoGear + m.bteleGear >= 12 Then
                m.bscore += 120
            ElseIf m.bautoGear + m.bteleGear >= 6 Then
                m.bscore += 80
            ElseIf m.bautoGear + m.bteleGear >= 2 Then
                m.bscore += 40
            End If
            m.rscore += 40
            If m.rautoGear > 2.5 Then
                m.rscore += 40
            ElseIf m.rautoGear >= 1 Then
                m.rscore += 20
            End If
            If m.rautoGear + m.rteleGear >= 12 Then
                m.rscore += 120
            ElseIf m.rautoGear + m.rteleGear >= 6 Then
                m.rscore += 80
            ElseIf m.rautoGear + m.rteleGear >= 2 Then
                m.rscore += 40
            End If
        Next
        Dim sorted = From pair In matches Order By pair.Key Ascending
        matches = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        currentMatch = CInt(File.ReadAllText(System.IO.Path.Combine(scoutDirectory, "Outputs/current.match")))
    End Sub
    Protected Overrides Sub WndProc(ByRef M As System.Windows.Forms.Message)
        '
        'These are the required subclassing codes for detecting device based removal and arrival.
        '
        If M.Msg = WM_DEVICECHANGE Then

            Select Case CInt(M.WParam)
                '
                'Check if a device was added.
                Case DBT_DEVICEARRIVAL

                    Dim DevType As Integer = Runtime.InteropServices.Marshal.ReadInt32(M.LParam, 4)

                    If DevType = DBT_DEVTYP_VOLUME Then

                        Dim Vol As New DEV_BROADCAST_VOLUME

                        Vol = CType(Runtime.InteropServices.Marshal.PtrToStructure(M.LParam, GetType(DEV_BROADCAST_VOLUME)), DEV_BROADCAST_VOLUME)

                        If Vol.Dbcv_Flags = 0 Then

                            For i As Integer = 0 To 20

                                If Math.Pow(2, i) = Vol.Dbcv_Unitmask Then

                                    Dim Usb As String = Chr(65 + i) + ":\"

                                    If File.Exists(Usb & "Scouting\Teams.csv") And File.Exists(Usb & "Scouting\Events.csv") And File.Exists(Usb & "Scouting\Optimization.csv") Then
                                        Dim BColor As Color = Me.BackColor
                                        If Not Directory.Exists(System.IO.Path.Combine(scoutDirectory, "Outputs")) Then
                                            Directory.CreateDirectory(System.IO.Path.Combine(scoutDirectory, "Outputs"))
                                        End If
                                        File.Copy(Usb & "Scouting\Teams.csv", System.IO.Path.Combine(scoutDirectory, "Outputs\Teams.csv"), True)
                                        File.Copy(Usb & "Scouting\Events.csv", System.IO.Path.Combine(scoutDirectory, "Outputs\Events.csv"), True)
                                        File.Copy(Usb & "Scouting\Optimization.csv", System.IO.Path.Combine(scoutDirectory, "Outputs\Optimization.csv"), True)
                                        File.Copy(Usb & "Scouting\current.match", System.IO.Path.Combine(scoutDirectory, "Outputs\current.match"), True)
                                        loadFile()
                                        For Each obj As Control In Me.Controls
                                            obj.Visible = False
                                        Next
                                    End If

                                    Exit For

                                End If

                            Next

                        End If

                    End If

            End Select

        End If

        MyBase.WndProc(M)

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        nextSlide()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        RemoveBrowerKey()
    End Sub

    Private Const BrowserKeyPath As String = "\SOFTWARE\Microsoft\Internet Explorer\MAIN\FeatureControl\FEATURE_BROWSER_EMULATION"
    Private Sub CreateBrowserKey(Optional ByVal IgnoreIDocDirective As Boolean = False)
        Dim basekey As String = Microsoft.Win32.Registry.CurrentUser.ToString
        Dim value As Int32
        Dim thisAppsName As String = My.Application.Info.AssemblyName & ".exe"
        ' Value reference: http://msdn.microsoft.com/en-us/library/ee330730%28v=VS.85%29.aspx
        ' IDOC Reference:  http://msdn.microsoft.com/en-us/library/ms535242%28v=vs.85%29.aspx
        Select Case (New WebBrowser).Version.Major
            Case 8
                If IgnoreIDocDirective Then
                    value = 8888
                Else
                    value = 8000
                End If
            Case 9
                If IgnoreIDocDirective Then
                    value = 9999
                Else
                    value = 9000
                End If
            Case 10
                If IgnoreIDocDirective Then
                    value = 10001
                Else
                    value = 10000
                End If

            Case 11
                If IgnoreIDocDirective Then
                    value = 11001
                Else
                    value = 11000
                End If
            Case Else
                Exit Sub
        End Select
        Microsoft.Win32.Registry.SetValue(Microsoft.Win32.Registry.CurrentUser.ToString & BrowserKeyPath, _
                                          Process.GetCurrentProcess.ProcessName & ".exe", _
                                          value, _
                                          Microsoft.Win32.RegistryValueKind.DWord)
    End Sub

    Private Sub RemoveBrowerKey()
        Dim key As Microsoft.Win32.RegistryKey
        key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(BrowserKeyPath.Substring(1), True)
        key.DeleteValue(Process.GetCurrentProcess.ProcessName & ".exe", False)
    End Sub

End Class