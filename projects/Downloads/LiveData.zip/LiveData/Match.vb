﻿Public Class Match
    Public rteam1 As Integer
    Public rteam2 As Integer
    Public rteam3 As Integer
    Public bteam1 As Integer
    Public bteam2 As Integer
    Public bteam3 As Integer
    Public rscore As Double
    Public bscore As Double
    Public rautoGear As Double
    Public bautoGear As Double
    Public rteleGear As Integer
    Public bteleGear As Integer
End Class
