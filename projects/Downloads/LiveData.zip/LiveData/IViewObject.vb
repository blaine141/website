﻿Imports System.Runtime.InteropServices
Imports System.Runtime.InteropServices.ComTypes
Imports System.Drawing

<ComVisible(True), ComImport> _
<GuidAttribute("0000010d-0000-0000-C000-000000000046")> _
<InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)> _
Public Interface IViewObject
    <PreserveSig()> _
    Function Draw(<MarshalAs(UnmanagedType.U4)> dwDrawAspect As UInt32, lindex As Integer, pvAspect As IntPtr, <[In]()> ptd As IntPtr, hdcTargetDev As IntPtr, hdcDraw As IntPtr, _
  <MarshalAs(UnmanagedType.Struct)> ByRef lprcBounds As Rectangle, <MarshalAs(UnmanagedType.Struct)> ByRef lprcWBounds As Rectangle, pfnContinue As IntPtr, <MarshalAs(UnmanagedType.U4)> dwContinue As UInt32) As <MarshalAs(UnmanagedType.I4)> Integer
    <PreserveSig()> _
    Function GetColorSet(<[In](), MarshalAs(UnmanagedType.U4)> dwDrawAspect As Integer, lindex As Integer, pvAspect As IntPtr, <[In]()> ptd As IntPtr, hicTargetDev As IntPtr, <Out()> ppColorSet As IntPtr) As Integer
    <PreserveSig()> _
    Function Freeze(<[In](), MarshalAs(UnmanagedType.U4)> dwDrawAspect As Integer, lindex As Integer, pvAspect As IntPtr, <Out()> pdwFreeze As IntPtr) As Integer
    <PreserveSig()> _
    Function Unfreeze(<[In](), MarshalAs(UnmanagedType.U4)> dwFreeze As Integer) As Integer
    Sub SetAdvise(<[In](), MarshalAs(UnmanagedType.U4)> aspects As Integer, <[In](), MarshalAs(UnmanagedType.U4)> advf As Integer, <[In](), MarshalAs(UnmanagedType.[Interface])> pAdvSink As IAdviseSink)
    Sub GetAdvise(<[In](), Out(), MarshalAs(UnmanagedType.LPArray)> paspects As Integer(), <[In](), Out(), MarshalAs(UnmanagedType.LPArray)> advf As Integer(), <[In](), Out(), MarshalAs(UnmanagedType.LPArray)> pAdvSink As IAdviseSink())
End Interface

