﻿Public Class BestClimbers
    Inherits Slide
    Public Shadows length As Integer = 10000
    Public Overrides Sub format()
        Dim sorted = From pair In teams Order By pair.Value.averageClimbTime / (pair.Value.climbAccuracy + 0.000000001) Ascending
        teams = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        Dim i As String = System.IO.File.ReadAllText("page/index.html")
        i = changeAttribute(i, "mdl-card__title-text", "Best Climbers")
        Try
            Dim team1 As Integer = 0
            While teams.Values(team1).averageClimbTime = 0
                team1 += 1
            End While
            Dim team As Integer = teams.Values(team1).num
            i = changeAttribute(i, "team1", team)
            team = teams.Values(team1 + 1).num
            i = changeAttribute(i, "team2", Team)
            team = teams.Values(team1 + 2).num
            i = changeAttribute(i, "team3", team)
            'i = changeAttribute(i, "team1", "Time: " & teams.Values(team1).averageClimbTime.ToString & " secs")
            'teams(team1).averageClimbTime()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        System.IO.File.WriteAllText("page/index.html", i)
        Dim hc As HtmlCapture = New HtmlCapture
        hc.Create("file:///" & IO.Path.GetFullPath("page\index.html"))
        While Not hc.gotImage
            Application.DoEvents()
        End While
        ClimberPictureBox.Image = hc.b
    End Sub

End Class