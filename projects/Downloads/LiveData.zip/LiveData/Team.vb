﻿Public Class Team
    Public num As Integer
    Public averageGearTime As Double = 0
    Public averageGearScore As Integer = 0
    Public averageClimbTime As Double = 0
    Public climbAccuracy As Double = 0
    Public averageFuelTime As Double = 0
    Public averageFuelScore As Double = 0
    Public gearEfficiency As Double = 0
    Public fuelEfficiency As Double = 0
    Public averageAutoGear As Double = 0
    Public crossLineAccuracy As Double = 0
    Public averageAutoFuel As Double = 0
End Class
