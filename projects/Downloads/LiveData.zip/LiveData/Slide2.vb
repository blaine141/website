﻿Public Class Slide2
    Public length As Integer = 10000

    Public Sub format()
        Team1.Text = ""
        Team2.Text = ""
        Team3.Text = ""
        Slide1_label.Width = Display.Width * 0.9
        Slide1_label.Location = New Point(Display.Width * 0.1, Display.Height * 0.05)
        Team1.Width = Display.Width
        Team1.Location = New Point(0, Display.Height * 0.3)
        Team2.Width = Display.Width
        Team2.Location = New Point(0, Display.Height * 0.5)
        Team3.Width = Display.Width
        Team3.Location = New Point(0, Display.Height * 0.7)
        Dim first As Double = 1000
        Dim second As Double = 1000
        Dim third As Double = 1000
        For Each t As Team In teams.Values
            If t.fuelEfficiency < first And t.fuelEfficiency <> 0 Then
                third = second
                second = first
                first = t.fuelEfficiency
            ElseIf t.fuelEfficiency < second And t.fuelEfficiency <> 0 Then
                third = second
                second = t.fuelEfficiency
            ElseIf t.fuelEfficiency < third And t.fuelEfficiency <> 0 Then
                third = t.fuelEfficiency
            End If
        Next
        For Each t As Team In teams.Values
            If t.fuelEfficiency = first And Team1.Text = "" Then
                Team1.Text = t.num.ToString
            ElseIf t.fuelEfficiency = second And Team2.Text = "" Then
                Team2.Text = t.num.ToString
            ElseIf t.fuelEfficiency = third And Team3.Text = "" Then
                Team3.Text = t.num.ToString
            End If
        Next
    End Sub

    Private Sub Slide2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class