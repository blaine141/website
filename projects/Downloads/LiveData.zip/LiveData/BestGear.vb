﻿
Public Class BestGear
    Inherits Slide
    Public Shadows length As Integer = 10000

    Public Overrides Sub format()
        Dim sorted = From pair In teams Order By pair.Value.gearEfficiency Descending
        teams = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        Dim i As String = System.IO.File.ReadAllText("page/index.html")
        i = changeAttribute(i, "mdl-card__title-text", "Best Gear Teams")
        Try
            Dim team As Integer = teams.Values(0).num
            i = changeAttribute(i, "team1", team)
            team = teams.Values(1).num
            i = changeAttribute(i, "team2", team)
            team = teams.Values(2).num
            i = changeAttribute(i, "team3", team)
        Catch
        End Try
        System.IO.File.WriteAllText("page/index.html", i)
        Dim hc As HtmlCapture = New HtmlCapture
        hc.Create("file:///" & IO.Path.GetFullPath("page\index.html"))
        While Not hc.gotImage
            Application.DoEvents()
        End While
        PictureBox1.Image = hc.b
    End Sub
End Class