﻿Public Class Slide1
    Public length As Integer = 10000

    Public Sub format()
        Team1.Text = ""
        Team2.Text = ""
        Team3.Text = ""
        Slide1_label.Width = Display.Width * 0.9
        Slide1_label.Location = New Point(Display.Width * 0.1, Display.Height * 0.05)
        Team1.Width = Display.Width
        Team1.Location = New Point(0, Display.Height * 0.3)
        Team2.Width = Display.Width
        Team2.Location = New Point(0, Display.Height * 0.5)
        Team3.Width = Display.Width
        Team3.Location = New Point(0, Display.Height * 0.7)
        Dim first As Double = 1000
        Dim second As Double = 1000
        Dim third As Double = 1000
        For Each t As Team In teams.Values
            If t.gearEfficiency < first And t.gearEfficiency <> 0 Then
                third = second
                second = first
                first = t.gearEfficiency
            ElseIf t.gearEfficiency < second And t.gearEfficiency <> 0 Then
                third = second
                second = t.gearEfficiency
            ElseIf t.gearEfficiency < third And t.gearEfficiency <> 0 Then
                third = t.gearEfficiency
            End If
        Next
        For Each t As Team In teams.Values
            If t.gearEfficiency = first And Team1.Text = "" Then
                Team1.Text = t.num.ToString
            ElseIf t.gearEfficiency = second And Team2.Text = "" Then
                Team2.Text = t.num.ToString
            ElseIf t.gearEfficiency = third And Team3.Text = "" Then
                Team3.Text = t.num.ToString
            End If
        Next
    End Sub

 
    Private Sub Slide1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class