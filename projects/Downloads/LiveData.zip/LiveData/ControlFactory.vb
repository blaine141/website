﻿Imports System
Imports System.Windows.Forms
Imports System.Reflection
Imports System.Collections
Imports System.ComponentModel
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Public Class ControlFactory
    Public Shared Function CreateControl(ctrlName As String, partialName As String) As Control

        Try
            Dim ctrl As Control
            Select Case (ctrlName)
                Case "Label"
                    ctrl = New Label()
                Case "TextBox"
                    ctrl = New TextBox()
                Case "PictureBox"
                    ctrl = New PictureBox()
                Case "ListView"
                    ctrl = New ListView()
                Case "ComboBox"
                    ctrl = New ComboBox()
                Case "Button"
                    ctrl = New Button()
                Case "CheckBox"
                    ctrl = New CheckBox()
                Case "MonthCalender"
                    ctrl = New MonthCalendar()
                Case "DateTimePicker"
                    ctrl = New DateTimePicker()
                Case "WebBrowser"
                    ctrl = New WebBrowser()
                Case Else
                    Dim controlAsm As Assembly = Assembly.LoadWithPartialName(partialName)
                    Dim controlType As Type = controlAsm.GetType(partialName + "." + ctrlName)
                    ctrl = New Control(Activator.CreateInstance(controlType))
            End Select

            Return ctrl


        Catch ex As Exception

            System.Diagnostics.Trace.WriteLine("create control failed:" + ex.Message)
            Return New Control()
        End Try

    End Function
    Public Shared Sub SetControlProperties(ctrl As Control, propertyList As Hashtable)
        Dim properties As PropertyDescriptorCollection = TypeDescriptor.GetProperties(ctrl)

        For Each myProperty As PropertyDescriptor In properties

            If propertyList.Contains(myProperty.Name) Then
                Dim obj As Object = propertyList(myProperty.Name)
                Try
                    myProperty.SetValue(ctrl, obj)
                Catch ex As Exception
                    'do nothing, just continue
                    System.Diagnostics.Trace.WriteLine(ex.Message)
                End Try


            End If
        Next
    End Sub
    Public Shared Function CloneCtrl(ctrl As Control) As Control

        Dim newCtrl As Control = ControlFactory.CreateControl(ctrl.GetType.Name, ctrl.GetType().FullName)
        Dim propertyList As Hashtable = New Hashtable()
        Dim properties As PropertyDescriptorCollection = TypeDescriptor.GetProperties(ctrl)

        For Each myProperty As PropertyDescriptor In properties
            Try
                If myProperty.PropertyType.IsSerializable Then
                    propertyList.Add(myProperty.Name, myProperty.GetValue(ctrl))
                End If
            Catch ex As Exception
                System.Diagnostics.Trace.WriteLine(ex.Message)
                'do nothing, just continue
            End Try

        Next
        ControlFactory.SetControlProperties(newCtrl, propertyList)

        Return newCtrl
    End Function
End Class
