﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Slide3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Slide3_Label = New System.Windows.Forms.Label()
        Me.PostName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Slide3_Label
        '
        Me.Slide3_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Slide3_Label.Location = New System.Drawing.Point(50, 9)
        Me.Slide3_Label.Name = "Slide3_Label"
        Me.Slide3_Label.Size = New System.Drawing.Size(401, 52)
        Me.Slide3_Label.TabIndex = 0
        Me.Slide3_Label.Text = "Last Drupal Post"
        Me.Slide3_Label.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PostName
        '
        Me.PostName.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PostName.Location = New System.Drawing.Point(67, 137)
        Me.PostName.Name = "PostName"
        Me.PostName.Size = New System.Drawing.Size(353, 115)
        Me.PostName.TabIndex = 1
        Me.PostName.Text = "Label1"
        Me.PostName.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Slide3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.PostName)
        Me.Controls.Add(Me.Slide3_Label)
        Me.Name = "Slide3"
        Me.Text = "Slide3"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Slide3_Label As System.Windows.Forms.Label
    Friend WithEvents PostName As System.Windows.Forms.Label
End Class
