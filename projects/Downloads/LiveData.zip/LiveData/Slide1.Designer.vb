﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Slide1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Slide1_label = New System.Windows.Forms.Label()
        Me.Team1 = New System.Windows.Forms.Label()
        Me.Team2 = New System.Windows.Forms.Label()
        Me.Team3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Slide1_label
        '
        Me.Slide1_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Slide1_label.Location = New System.Drawing.Point(34, 9)
        Me.Slide1_label.Name = "Slide1_label"
        Me.Slide1_label.Size = New System.Drawing.Size(674, 103)
        Me.Slide1_label.TabIndex = 0
        Me.Slide1_label.Text = "Best Gear Teams:"
        '
        'Team1
        '
        Me.Team1.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Team1.Location = New System.Drawing.Point(125, 129)
        Me.Team1.Name = "Team1"
        Me.Team1.Size = New System.Drawing.Size(475, 107)
        Me.Team1.TabIndex = 1
        Me.Team1.Text = "Team1"
        '
        'Team2
        '
        Me.Team2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Team2.Location = New System.Drawing.Point(125, 196)
        Me.Team2.Name = "Team2"
        Me.Team2.Size = New System.Drawing.Size(475, 107)
        Me.Team2.TabIndex = 2
        Me.Team2.Text = "Team2"
        '
        'Team3
        '
        Me.Team3.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Team3.Location = New System.Drawing.Point(125, 252)
        Me.Team3.Name = "Team3"
        Me.Team3.Size = New System.Drawing.Size(475, 107)
        Me.Team3.TabIndex = 3
        Me.Team3.Text = "Team3"
        '
        'Slide1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(932, 368)
        Me.Controls.Add(Me.Team3)
        Me.Controls.Add(Me.Team2)
        Me.Controls.Add(Me.Team1)
        Me.Controls.Add(Me.Slide1_label)
        Me.Name = "Slide1"
        Me.Text = "Slide1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Slide1_label As System.Windows.Forms.Label
    Friend WithEvents Team1 As System.Windows.Forms.Label
    Friend WithEvents Team2 As System.Windows.Forms.Label
    Friend WithEvents Team3 As System.Windows.Forms.Label
End Class
