﻿Public Class DreamAlliance
    Inherits Slide
    Public Shadows length As Integer = 10000
    Public Overrides Sub format()
        Dim max As Double = 0
        Dim team1m As Team = Nothing
        Dim team2m As Team = Nothing
        Dim team3m As Team = Nothing
        For x As Integer = 0 To teams.Count - 1
            For y As Integer = x + 1 To teams.Count - 1
                For z As Integer = y + 1 To teams.Count - 1
                    Dim score As Double = 0
                    Dim team1 As Team = teams.Values(x)
                    Dim team2 As Team = teams.Values(y)
                    Dim team3 As Team = teams.Values(z)
                    score += 5 * (team1.crossLineAccuracy + team2.crossLineAccuracy + team3.crossLineAccuracy)
                    score += team1.averageFuelScore + team1.averageAutoFuel + team2.averageFuelScore + team2.averageAutoFuel + team3.averageFuelScore + team3.averageAutoFuel
                    score += 50 * (team1.climbAccuracy + team2.climbAccuracy + team3.climbAccuracy)
                    If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1.averageGearScore + team2.averageGearScore + team3.averageGearScore >= 12 Then
                        score += 40
                    End If
                    If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1.averageGearScore + team2.averageGearScore + team3.averageGearScore >= 6 Then
                        score += 40
                    End If
                    If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 2.5 Then
                        score += 60
                    ElseIf team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1.averageGearScore + team2.averageGearScore + team3.averageGearScore >= 2 Then
                        score += 40
                    End If
                    If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 1 Then
                        score += 60
                    Else
                        score += 40
                    End If
                    If score > max Then
                        team1m = team1
                        team2m = team2
                        team3m = team3
                        max = score
                    End If
                Next
            Next
        Next
        Dim i As String = System.IO.File.ReadAllText("page/dreamAlliance.html")
        i = changeAttribute(i, "mdl-card__title-text", "The Dream Alliance")
        Try
            i = changeAttribute(i, "team1", team1m.num)
            i = changeAttribute(i, "team2", team2m.num)
            i = changeAttribute(i, "team3", team3m.num)
            i = changeAttribute(i, "score", "Score: " & max.ToString("N1"))
        Catch
        End Try
        System.IO.File.WriteAllText("page/dreamAlliance.html", i)
        Dim hc As HtmlCapture = New HtmlCapture
        hc.Create("file:///" & IO.Path.GetFullPath("page\dreamAlliance.html"))
        While Not hc.gotImage
            Application.DoEvents()
        End While
        PictureBox1.Image = hc.b
        'Label5.Text = "Score: " & max
    End Sub
End Class