﻿Public Class TeamSlide
    Inherits Slide
    Shadows length As Integer = 1000
    Public Overrides Sub format()
        Dim teamNum As Integer = teams.Keys(Math.Floor((teams.Count) * Rnd()))
        label1.Text = "All About Team " & teamNum.ToString
        'label1.Width = Display.Width
        'label1.Location = New Point(0, Display.Height * 0.02)
        Dim spk As Integer = 0
        If teams(teamNum).fuelEfficiency <> 0 Then
            spk = 1 / teams(teamNum).fuelEfficiency
        End If
        Dim spg As Integer = 0
        If teams(teamNum).gearEfficiency <> 0 Then
            spg = 1 / teams(teamNum).gearEfficiency
        End If
        Label2.Text = "Fuel Efficiency: " & spk & " s/kPa"
        Label3.Text = "Gear Efficiency: " & spg & " s/Gear"
    End Sub


End Class