﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BestClimbers
    Inherits LiveData.Slide

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ClimberPictureBox = New System.Windows.Forms.PictureBox()
        CType(Me.ClimberPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ClimberPictureBox
        '
        Me.ClimberPictureBox.Location = New System.Drawing.Point(0, 0)
        Me.ClimberPictureBox.Name = "ClimberPictureBox"
        Me.ClimberPictureBox.Size = New System.Drawing.Size(1280, 800)
        Me.ClimberPictureBox.TabIndex = 0
        Me.ClimberPictureBox.TabStop = False
        '
        'BestClimbers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 741)
        Me.Controls.Add(Me.ClimberPictureBox)
        Me.Name = "BestClimbers"
        Me.Text = "BestClimbers"
        CType(Me.ClimberPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ClimberPictureBox As System.Windows.Forms.PictureBox
End Class
