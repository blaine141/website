﻿Public Class Title
    Inherits Slide
    Public Shadows length As Integer = 10000

    Public Overrides Sub format()
        Dim hc As HtmlCapture = New HtmlCapture
        hc.Create("file:///" & IO.Path.GetFullPath("page\title.html"))
        While Not hc.gotImage
            Application.DoEvents()
        End While
        PictureBox1.Image = hc.b
    End Sub
End Class