﻿Public Class Slide3
    Public length As Integer = 10000

    Public Sub format()
        Dim webClient As New System.Net.WebClient
        'Dim result As String = webClient.DownloadString("http://ozone.worthconsulting.com/blaine")
        Slide3_Label.Location = New Point(0, Display.Height * 0.05)
        Slide3_Label.Width = Display.Width
        PostName.Width = Display.Width
        PostName.Location = New Point(0, Display.Height / 2 - PostName.Height / 2)
        'PostName.Text = result.Substring(result.IndexOf(">") + 1, result.IndexOf("<", result.IndexOf(">")) - result.IndexOf(">") - 1)
    End Sub
End Class