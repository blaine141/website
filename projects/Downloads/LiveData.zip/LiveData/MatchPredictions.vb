﻿Public Class MatchPredictions
    Inherits Slide
    Public Shadows length As Integer = 10000

    Public Overrides Sub format()
        Dim i As String = System.IO.File.ReadAllText("page/matchPredictions.html")
        Try
            Dim matchLoc
            For matchLoc = 0 To matches.Count
                If matches.Keys(matchLoc) > currentMatch Then
                    Exit For
                End If
            Next
            While matches.Values(matchLoc).bteam1 = 0 Or matches.Values(matchLoc).bteam2 = 0 Or matches.Values(matchLoc).bteam3 = 0 Or matches.Values(matchLoc).rteam1 = 0 Or matches.Values(matchLoc).rteam2 = 0 Or matches.Values(matchLoc).rteam3 = 0
                matchLoc += 1
            End While
            i = changeAttribute(i, "match1title", "Match " & matches.Keys(matchLoc).ToString & " Prediction")
            i = changeAttribute(i, "match1_team1", matches.Values(matchLoc).bteam1)
            i = changeAttribute(i, "match1_team2", matches.Values(matchLoc).bteam2)
            i = changeAttribute(i, "match1_team3", matches.Values(matchLoc).bteam3)
            i = changeAttribute(i, "match1_team4", matches.Values(matchLoc).rteam1)
            i = changeAttribute(i, "match1_team5", matches.Values(matchLoc).rteam2)
            i = changeAttribute(i, "match1_team6", matches.Values(matchLoc).rteam3)
            i = changeAttribute(i, "match1_bScore", CInt(matches.Values(matchLoc).bscore))
            i = changeAttribute(i, "match1_rScore", CInt(matches.Values(matchLoc).rscore))
            matchLoc += 1
            While matches.Values(matchLoc).bteam1 = 0 Or matches.Values(matchLoc).bteam2 = 0 Or matches.Values(matchLoc).bteam3 = 0 Or matches.Values(matchLoc).rteam1 = 0 Or matches.Values(matchLoc).rteam2 = 0 Or matches.Values(matchLoc).rteam3 = 0
                matchLoc += 1
            End While
            i = changeAttribute(i, "match2title", "Match " & matches.Keys(matchLoc).ToString & " Prediction")
            i = changeAttribute(i, "match2_team1", matches.Values(matchLoc).bteam1)
            i = changeAttribute(i, "match2_team2", matches.Values(matchLoc).bteam2)
            i = changeAttribute(i, "match2_team3", matches.Values(matchLoc).bteam3)
            i = changeAttribute(i, "match2_team4", matches.Values(matchLoc).rteam1)
            i = changeAttribute(i, "match2_team5", matches.Values(matchLoc).rteam2)
            i = changeAttribute(i, "match2_team6", matches.Values(matchLoc).rteam3)
            i = changeAttribute(i, "match2_bScore", CInt(matches.Values(matchLoc).bscore))
            i = changeAttribute(i, "match2_rScore", CInt(matches.Values(matchLoc).rscore))
            matchLoc += 1
            While matches.Values(matchLoc).bteam1 = 0 Or matches.Values(matchLoc).bteam2 = 0 Or matches.Values(matchLoc).bteam3 = 0 Or matches.Values(matchLoc).rteam1 = 0 Or matches.Values(matchLoc).rteam2 = 0 Or matches.Values(matchLoc).rteam3 = 0
                matchLoc += 1
            End While
            i = changeAttribute(i, "match3title", "Match " & matches.Keys(matchLoc).ToString & " Prediction")
            i = changeAttribute(i, "match3_team1", matches.Values(matchLoc).bteam1)
            i = changeAttribute(i, "match3_team2", matches.Values(matchLoc).bteam2)
            i = changeAttribute(i, "match3_team3", matches.Values(matchLoc).bteam3)
            i = changeAttribute(i, "match3_team4", matches.Values(matchLoc).rteam1)
            i = changeAttribute(i, "match3_team5", matches.Values(matchLoc).rteam2)
            i = changeAttribute(i, "match3_team6", matches.Values(matchLoc).rteam3)
            i = changeAttribute(i, "match3_bScore", CInt(matches.Values(matchLoc).bscore))
            i = changeAttribute(i, "match3_rScore", CInt(matches.Values(matchLoc).rscore))
            matchLoc += 1
            While matches.Values(matchLoc).bteam1 = 0 Or matches.Values(matchLoc).bteam2 = 0 Or matches.Values(matchLoc).bteam3 = 0 Or matches.Values(matchLoc).rteam1 = 0 Or matches.Values(matchLoc).rteam2 = 0 Or matches.Values(matchLoc).rteam3 = 0
                matchLoc += 1
            End While
            i = changeAttribute(i, "match4title", "Match " & matches.Keys(matchLoc).ToString & " Prediction")
            i = changeAttribute(i, "match4_team1", matches.Values(matchLoc).bteam1)
            i = changeAttribute(i, "match4_team2", matches.Values(matchLoc).bteam2)
            i = changeAttribute(i, "match4_team3", matches.Values(matchLoc).bteam3)
            i = changeAttribute(i, "match4_team4", matches.Values(matchLoc).rteam1)
            i = changeAttribute(i, "match4_team5", matches.Values(matchLoc).rteam2)
            i = changeAttribute(i, "match4_team6", matches.Values(matchLoc).rteam3)
            i = changeAttribute(i, "match4_bScore", CInt(matches.Values(matchLoc).bscore))
            i = changeAttribute(i, "match4_rScore", CInt(matches.Values(matchLoc).rscore))
            'i = changeAttribute(i, "team1", "Time: " & teams.Values(team1).averageClimbTime.ToString & " secs")
            'teams(team1).averageClimbTime()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        System.IO.File.WriteAllText("page/matchPredictions.html", i)
        Dim hc As HtmlCapture = New HtmlCapture
        hc.Create("file:///" & IO.Path.GetFullPath("page\matchPredictions.html"))
        While Not hc.gotImage
            Application.DoEvents()
        End While
        PictureBox1.Image = hc.b
    End Sub

    Private Sub MatchPredictions_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class