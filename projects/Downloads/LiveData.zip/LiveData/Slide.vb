﻿Public Class Slide
    Inherits System.Windows.Forms.Form
    Public length As Integer

    Public Overridable Sub format()
    End Sub

End Class