#include <18F2450.h>
#device ICD=true
#use delay(clock=16384000)
#fuses HSPLL,PLL4,NOPBADEN,NOEBTR,NOWDT,NOLVP,BROWNOUT,NOWRT,NOPUT//,DEBUG
#use rs232(baud=115200, PARITY=N, BITS=8, STOP=1, RCV=PIN_C7,XMIT=PIN_C6, ERRORS)
#define CLOCK PIN_B0
#define DATA PIN_C1

enum mode{IDLE, RECEIVING1, RECEIVING2, RECEIVING3, SENDING1, SENDING2};

int dataToSend = 0;
int lineMode = IDLE;
int receivedData;
int dataPos;
char inBuffer [128];
char outBuffer[128] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int addToOutputBufferPointer = 0;
int bufferPointer;
int byteNum=0;
int shouldResetTimer = false;
int communicating = 0;
int interruptsDisabled = 0;

void SetBluetoothState(int state) {
	if(state) {
		output_high(PIN_A1);
		output_high(PIN_A2);
		output_high(PIN_A3);
		output_high(PIN_A4);
		output_high(PIN_A5);
		output_high(PIN_C0);
	}
	else {
		output_low(PIN_A1);
		output_low(PIN_A2);
		output_low(PIN_A3);
		output_low(PIN_A4);
		output_low(PIN_A5);
		output_low(PIN_C0);
	}
}

void BackToIdle()
{
	output_float(DATA);
	lineMode = IDLE;
	ext_int_edge( 0, H_TO_L);
	communicating=0;
}


void Main() {
	set_tris_a(0b00111111);
	set_tris_b(0b00111111);
	set_tris_c(0b11111111);
	port_b_pullups(false);
	ext_int_edge( 0, H_TO_L); //pin B2
	setup_timer_0(RTCC_DIV_256);
	disable_interrupts(INT_TIMER0);
	clear_interrupt(INT_EXT);
	enable_interrupts(INT_EXT);
	enable_interrupts(GLOBAL);
	SetBluetoothState(true);
	while(true) { 
		/*if(lineMode != RECEIVING1 && lineMode != RECEIVING2 && kbhit())
		{
			disable_interrupts(INT_EXT);
			lineMode = IDLE;
			interruptsDisabled = true;
			output_float(DATA); 
			int done = 0;
			SET_TIMER0(60000);
			char a;
			while(!done && get_timer0()>=60000)
			{
				while(kbhit())
				{
					SET_TIMER0(60000);
					a = getc();
					if(a == '.')
						done = true;
					else
						outBuffer[addToOutputBufferPointer++] = a;
				}
			}
			enable_interrupts(INT_EXT);
			BackToIdle();
			interruptsDisabled = false;
		}
		if(lineMode == IDLE && inBuffer[0]!=0)
		{
			puts(inBuffer);
			inBuffer = "";
		}
		if(shouldResetTimer == 1)
		{
			SET_TIMER0(60000);
			communicating = 1;
			shouldResetTimer = 0;
		}
		if(shouldResetTimer == 2)
		{
			SET_TIMER0(60000);
			shouldResetTimer = 0;
		}
		if(communicating && get_timer0()<60000)
			BackToIdle();*/
	}	
}	

#INT_EXT	
void Clocked() {
	if(lineMode == IDLE) {
		if(!input(DATA)) {
			output_low(DATA);
			lineMode = SENDING1;
		}
		else {
			output_low(DATA);
			lineMode = RECEIVING1;
		}
		shouldResetTimer = 1;
	}
	else if(lineMode == RECEIVING1) {
		shouldResetTimer = 2;
		output_float(DATA);
		dataToSend = outBuffer[0] !=0;
		if(dataToSend)
			output_low(DATA);
		dataPos = 9;//10;
		receivedData = 0;
		byteNum=0;
		lineMode = RECEIVING2;			
	}
	else if(lineMode == RECEIVING2) {
		shouldResetTimer = 2;
		output_float(DATA);
		ext_int_edge( 0, L_TO_H);
		lineMode = RECEIVING3;
	}
	else if(lineMode == RECEIVING3) {
		output_float(DATA);
		shouldResetTimer = 2;
		if(input(CLOCK)) {
			if(--dataPos== 0) {
				if(input(DATA)) {
					inBuffer[byteNum++] = receivedData;
					inBuffer[byteNum] = 0;
					lineMode = IDLE;
					ext_int_edge( 0, H_TO_L);
				}
				else {
					inBuffer[byteNum++] = receivedData;
					dataPos = 9;//10;
					receivedData = 0;
				}
			}
			//else if(dataPos==1)
			//{
			//	output_low(DATA);
			//}
			else {
				if(input(DATA))
					bit_clear(receivedData,dataPos-2);
				else
					bit_set(receivedData,dataPos-2);
			}
		}
	}
	else if(lineMode == SENDING1) {
		shouldResetTimer = 2;
		output_float(DATA);
		dataPos = 8;
		bufferPointer = 0;
		lineMode = SENDING2;
	}
	else if(lineMode == SENDING2) {
		shouldResetTimer = 2;
		if(dataPos == 0) {
			dataPos = 8;
			output_float(DATA);
			if(outBuffer[bufferPointer]==0||outBuffer[bufferPointer+1]==0)
			{
				lineMode = IDLE;
				addToOutputBufferPointer=0;
			}
			else
				output_low(DATA);
			outBuffer[bufferPointer++]=0;
		}
		else {
			output_float(DATA);
			if(bit_test(outBuffer[bufferPointer],--dataPos))
				output_low(DATA);
		}
	}
}	


