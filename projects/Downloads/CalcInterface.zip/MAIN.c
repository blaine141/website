#include <18F2450.h>
#device ICD=true
#use delay(clock=16384000)
#fuses HSPLL,PLL4,NOPBADEN,NOEBTR,NOWDT,NOLVP,BROWNOUT,NOWRT,NOPUT//,DEBUG
#use rs232(baud=115200, PARITY=N, BITS=8, STOP=1, RCV=PIN_C7,XMIT=PIN_C6, ERRORS)
#define CLOCK PIN_B0
#define DATA PIN_C1
int receivingByte = false;
int receivedData = 0;
int dataPos = 0;
int bluetoothOn = 1;
int sendingByte = 0;
int bitsSent = 0;
int byteToSend = 0;
int connectedToPhone = 0;
void Send();


void Main()
{
	set_tris_a(0b00111111);
	set_tris_b(0b00111111);
	set_tris_c(0b11111111);
	port_b_pullups(false);
	ext_int_edge( 0, H_TO_L); //pin B2
	setup_timer_0(RTCC_DIV_256);
	disable_interrupts(INT_TIMER0);
	clear_interrupt(INT_EXT);
	enable_interrupts(INT_EXT);
	enable_interrupts(GLOBAL);
	output_high(PIN_A1);
	output_high(PIN_A2);
	output_high(PIN_A3);
	output_high(PIN_A4);
	output_high(PIN_A5);
	output_high(PIN_C0);
	while(true)
	{	
		if(kbhit()&&!receivingByte)
		{
			byteToSend = getc();
			if(byteToSend=='N')
				connectedToPhone=0;
			else if(byteToSend=='1')
				connectedToPhone=1;
			else
				Send();
		}	
		if(receivingByte&&dataPos==8)
		{
			receivingByte=false;
			dataPos=0;
			if(receivedData == 7||(receivedData==2&&!bluetoothOn))
			{
				bluetoothOn = !bluetoothOn;
				if(bluetoothOn)
				{
					output_high(PIN_A1);
					output_high(PIN_A2);
					output_high(PIN_A3);
					output_high(PIN_A4);
					output_high(PIN_A5);
					output_high(PIN_C0);
				} else {
					output_low(PIN_A1);
					output_low(PIN_A2);
					output_low(PIN_A3);
					output_low(PIN_A4);
					output_low(PIN_A5);
					output_low(PIN_C0);
					connectedToPhone = 0;
				}	
			}	
			else if(bluetoothOn&&receivedData&&receivedData!=0xFF)
			{
				putc(receivedData);	
			}
			if(receivedData==2||receivedData==0)
			{
				if(connectedToPhone)
					byteToSend='C';
				else
					byteToSend='N';
				Send();
			} else
				clear_interrupt(INT_EXT);
			enable_interrupts(INT_EXT);
			
			if(!bluetoothOn)
				sleep();
		}	
	}	
}
void Send()
{
	bitsSent=0;
	output_float(DATA);
	disable_interrupts(INT_EXT);
	output_low(CLOCK);
	while(input(DATA)){}	
	output_float(CLOCK);
	sendingByte=1;
	set_timer0(0);
	enable_interrupts(INT_TIMER0);
	clear_interrupt(INT_EXT);
	enable_interrupts(INT_EXT);
	while(sendingByte){}
}	

#INT_EXT	
void Clocked()
{
	if(sendingByte)
	{
		disable_interrupts(INT_EXT);
		output_float(DATA);if(bit_test(byteToSend,7-bitsSent))
			output_low(DATA);
		output_low(CLOCK);
		delay_us(50);
		set_timer0(0);
		if(bitsSent++==7)
		{
			sendingByte = 0;
			disable_interrupts(INT_TIMER0);
		}	
		output_float(DATA);
		output_float(CLOCK);
		clear_interrupt(INT_EXT);
		enable_interrupts(INT_EXT);
	} else {	
		if(receivingByte)
		{
			output_float(DATA);
			delay_us(100);
			if(input(DATA))
				bit_clear(receivedData,dataPos);
			else
				bit_set(receivedData,dataPos);
			if(++dataPos==8)
				disable_interrupts(INT_EXT);
		}
		else
		{
			receivingByte = true;	
			output_low(DATA);
		}	
	}	
}	

#INT_TIMER0
void CalcNotListening()
{
	sendingByte = 0;
	disable_interrupts(INT_TIMER0);
}	