#include <18F2450.h>
#device ICD=true
#use delay(clock=16384000)
#fuses HSPLL,PLL4,NOPBADEN,NOEBTR,NOWDT,NOLVP,BROWNOUT,NOWRT,NOPUT//,DEBUG
#use rs232(baud=115200, PARITY=N, BITS=8, STOP=1, RCV=PIN_C7,XMIT=PIN_C6, ERRORS)
#define CLOCK PIN_B0
#define DATA PIN_C1

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*  Signal Diagram: wavedrom.com/editor.html

{signal: [
  ['Send',
  	{name: 'clk', wave: '1.n..p........n.ph|.'},
  	{name: 'dat', wave: '1.341555555554131.|.', data: ['calc', 'dp', 'b0', 'b1','b2','b3','b4','b5','b6','b7','more','ack']}
  ],{},{},
  ['Fetch',
  	{name: 'clk', wave: '1.lhnn........h..|..'},
  	{name: 'dat', wave: '1.l355555555431..|..', data: [ 'calc', 'b0', 'b1','b2','b3','b4','b5','b6','b7','more','alive']}
  ]
]}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/


enum mode{IDLE, RECEIVING1, RECEIVING2, RECEIVING3, RECEIVING4, RECEIVING5, RECEIVING6, SENDING1, SENDING2};

int dataToSend = 0;
int lineMode = IDLE;
int receivedData;
int dataPos;
char inBuffer [128];
char outBuffer[128] = {'N','e','r','d',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int addToOutputBufferPointer = 0;
int bufferPointer;
int byteNum = 0;
int moreData = 0;
int communicating = 0;
int shouldResetTimer = 0;

void SetBluetoothState(int state) {
	if(state) { 
		output_high(PIN_A1);
		output_high(PIN_A2);
		output_high(PIN_A3);
		output_high(PIN_A4);
		output_high(PIN_A5);
		output_high(PIN_C0);
	}
	else {
		output_low(PIN_A1);
		output_low(PIN_A2);
		output_low(PIN_A3);
		output_low(PIN_A4);
		output_low(PIN_A5);
		output_low(PIN_C0);
	}
}

void BackToIdle()
{
	output_float(DATA);
	lineMode = IDLE;
	communicating = 0;
}

void Main() {
	set_tris_a(0b00111111);
	set_tris_b(0b00111111);
	set_tris_c(0b11111111);
	port_b_pullups(false);
	ext_int_edge( 0, H_TO_L); //pin B2
	setup_timer_0(RTCC_DIV_256);
	disable_interrupts(INT_TIMER0);
	clear_interrupt(INT_EXT);
	enable_interrupts(INT_EXT);
	enable_interrupts(GLOBAL);
	SetBluetoothState(true);
	while(true) { 
		if(shouldResetTimer == 1)
		{
			SET_TIMER0(60000);
			communicating = 1;
			shouldResetTimer = 0;
		}
		if(inBuffer[0]!=0)
		{
			puts(inBuffer);
			strcpy(inBuffer,"");
		}
		if(communicating && get_timer0()<60000)
			BackToIdle();
	}	
}	

#INT_EXT	
void Clocked() {
	shouldResetTimer = 1;
	if(lineMode == IDLE) {
		if(input(DATA))
		{
			output_low(DATA);
			lineMode = RECEIVING1;
		}
		else
		{
			output_low(DATA);
			bufferPointer = 0;
			dataPos = 8;
			lineMode = SENDING1;
		}
	}
	else if(lineMode == RECEIVING1) {
		output_float(DATA);
		dataToSend = outBuffer[0]!=0;
		if(dataToSend)
			output_low(DATA);
		dataPos = 8;
		byteNum=0;
		lineMode = RECEIVING2;			
	}
	else if(lineMode == RECEIVING2) {
		output_float(DATA);
		lineMode = RECEIVING3;
	}
	else if(lineMode == RECEIVING3) {
		if(--dataPos == 0)
			lineMode = RECEIVING4;
		if(input(DATA))
			bit_clear(receivedData,dataPos);
		else
			bit_set(receivedData,dataPos);
	}
	else if(lineMode == RECEIVING4) {
		moreData = !input(DATA);
		if(receivedData!=0)
			inBuffer[byteNum++] = receivedData;
		dataPos = 8;
		lineMode = RECEIVING5;
	}
	else if(lineMode == RECEIVING5) {
		output_low(DATA);
		lineMode = RECEIVING6;
	}
	else if(lineMode == RECEIVING6) {
		output_float(DATA);
		if(moreData)
			lineMode = RECEIVING3;
		else
		{
			if(receivedData != 0)
				inBuffer[byteNum]=0;
			lineMode = IDLE;
		}
	}
	else if(lineMode == SENDING1) {
		output_float(DATA);
		if(bit_test(outBuffer[bufferPointer],--dataPos))
			output_low(DATA);
		if(dataPos == 0)
			lineMode = SENDING2;
	}
	else if(lineMode == SENDING2)
	{
		output_float(DATA);
		dataPos = 8;
		lineMode = SENDING1;
		if(outBuffer[bufferPointer]==0||outBuffer[bufferPointer+1]==0)
		{
			lineMode = IDLE;
			addToOutputBufferPointer=0;
		}
		else
			output_low(DATA);
		outBuffer[bufferPointer++]=0;
	}
	else
		shouldResetTimer = 0;

}	


