﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace ShopBoard
{
    public partial class Form1 : Form
    {
        public const int WIDTH = 60;
        public const int HEIGHT = 1;
        public Color[,] lastBoard = new Color[HEIGHT, WIDTH];
        public Color[,] board = new Color[HEIGHT, WIDTH];
        SerialPort CommPort = new SerialPort();
        public Form1()
        {
            InitializeComponent();
            AppDomain.CurrentDomain.ProcessExit += new EventHandler(closing);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            numericUpDown4.Maximum = WIDTH;
            for (int i = 0; i < HEIGHT*WIDTH-1;i++ )
            {
                lastBoard[i / WIDTH, i % WIDTH] = Color.FromArgb(255, 255, 255);
            }
            foreach (String port in SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(port);
            }
        }
        private void closing(object sender, EventArgs e)
        {
            board = new Color[HEIGHT, WIDTH];
            if (CommPort.IsOpen)updateDisplay();
            CommPort.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            //Color temp = board[0, 0];
            for (int i = 0; i < HEIGHT*WIDTH-1;i++ )
            {
                //board[i / WIDTH, i % WIDTH] = board[(i + 1) / WIDTH, (i + 1) % WIDTH];
                board[i / WIDTH, i % WIDTH] = Color.FromArgb((board[i / WIDTH, i % WIDTH].R + 2) % 256,board[i / WIDTH, i % WIDTH].G, board[i / WIDTH, i % WIDTH].B);
            }
            //board[HEIGHT-1, WIDTH-1] = temp;
            updateDisplay();
            timer1.Enabled = true;
        }
        public bool updateDisplay()
        {
            List<Char> buffer = new List<Char>();  
            for(int i = 0; i<HEIGHT*WIDTH;i++ )
            {
                if(!same(board[i/WIDTH,i%WIDTH],lastBoard[i/WIDTH,i%WIDTH]))
                {
                    buffer.Add((char)(i / WIDTH));
                    buffer.Add((char)(i % WIDTH));
                    for (int test = i; test < HEIGHT * WIDTH; test++)
                    {
                        if ((test == HEIGHT * WIDTH - 1)||(same(board[test / WIDTH, test % WIDTH], lastBoard[test / WIDTH, test % WIDTH]) && same(board[(test + 1) / WIDTH, (test + 1) % WIDTH], lastBoard[(test + 1) / WIDTH, (test + 1) % WIDTH]) && ((test>=HEIGHT*WIDTH-2)||same(board[(test + 2) / WIDTH, (test + 2) % WIDTH], lastBoard[(test + 2) / WIDTH, (test + 2) % WIDTH]))) || (test - i+1 == 255))
                        {
                            buffer.Add((char)(test - i+1));
                            for(int index = i; index<=test; index++)
                            {
                                buffer.Add((char)(board[index / WIDTH, index % WIDTH].R));
                                buffer.Add((char)(board[index / WIDTH, index % WIDTH].G));
                                buffer.Add((char)(board[index / WIDTH, index % WIDTH].B));
                            }
                            i = test;
                            break;
                        }
                    }
                }
            }
            buffer.Add((char)(0));
            buffer.Add((char)(0));
            buffer.Add((char)(0));
            CommPort.WriteTimeout = 250;
            CommPort.Write("S");
            for (int row = 0; row < HEIGHT; row++)
            {
                for (int col = 0; col < WIDTH; col++)
                {
                    lastBoard[row, col] = Color.FromArgb(board[row, col].R, board[row, col].G, board[row, col].B);
                }
            }
            DateTime then = DateTime.Now;
            bool refreshed = false;
            while (CommPort.BytesToRead == 0)
            {
                Application.DoEvents();
                if(DateTime.Now.Subtract(then).TotalMilliseconds>250)
                {
                    if(refreshed)
                    {
                        MessageBox.Show("Could not connect to board on this port.");
                        return false;
                    }
                    for (int i = 0; i < HEIGHT * WIDTH;i++ )
                    {
                        CommPort.Write(""+(char)(0));
                        CommPort.Write("" + (char)(0));
                        CommPort.Write("" + (char)(0));
                    }
                    Thread.Sleep(250);
                    CommPort.Write("S");
                    refreshed = true;
                    then = DateTime.Now;
                }
            }
            CommPort.WriteTimeout = SerialPort.InfiniteTimeout;
            CommPort.DiscardInBuffer();
            CommPort.Write(buffer.ToArray(), 0, buffer.Count);
            return true;
        }
        public bool same(Color a, Color b)
        {
            return(a.R==b.R&&a.G==b.G&&a.B==b.B );
        }

        private void button1_Click(object sender, EventArgs e)
        {
            board[0, (int)(numericUpDown4.Value)-1] = Color.FromArgb((int)(numericUpDown1.Value), (int)(numericUpDown2.Value), (int)(numericUpDown3.Value));
            updateDisplay();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "Connect")
            {
                try
                {
                    CommPort.PortName = comboBox1.SelectedItem.ToString();
                    CommPort.BaudRate = 115200;
                    CommPort.DataBits = 8;
                    CommPort.Parity = Parity.None;
                    CommPort.StopBits = StopBits.One;
                    CommPort.Handshake = Handshake.None;
                    CommPort.Encoding = System.Text.Encoding.Default;
                    CommPort.Open();
                    if (updateDisplay())
                    {
                        foreach (Control c in groupBox1.Controls)
                        {
                            c.Enabled = true;
                        }
                        button2.Text = "Disconnect";
                    }
                    else
                    {
                        CommPort.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    CommPort.Close();
                }
            }
            else
            {
                try
                {
                    board = new Color[HEIGHT, WIDTH];
                    updateDisplay();
                }
                catch(Exception ex){}
                try
                {
                    button2.Text = "Connect";
                    foreach (Control c in groupBox1.Controls)
                    {
                        c.Enabled = false;
                    }
                    CommPort.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    CommPort.Close();                
                }
            }
        }


   
    }

}
