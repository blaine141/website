﻿Imports System.Drawing
Public Class Mono
    Public a As Color = Color.FromArgb(0, 0, 0)


    Private Sub Mono_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.BackColor = a
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ColorDialog1.ShowDialog() = DialogResult.OK Then
            Label1.BackColor = ColorDialog1.Color
            a = ColorDialog1.Color
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If SolidButton.Checked Then
            plan = New Color(0, 0) {}
            plan(0, 0) = a
        End If
        If FlashButton.Checked Then
            plan = New Color(1, 0) {}
            plan(0, 0) = a
            plan(1, 0) = Color.FromArgb(0, 0, 0)
        End If
        If FadeButton.Checked Then
            Dim resolution As Integer = 64
            plan = New Color(2 * resolution, 0) {}
            For time = 0 To 2 * resolution
                plan(time, 0) = Color.FromArgb(Math.Abs(time - resolution) / resolution * a.R, Math.Abs(time - resolution) / resolution * a.G, Math.Abs(time - resolution) / resolution * a.B)
            Next
        End If
        options = options Or 1
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class