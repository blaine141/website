﻿Public Class SettingsScreen

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Settings.Rate = NumericUpDown2.Value
        If My.Settings.Lights <> NumericUpDown1.Value Then
            options = 1
            plan = {{System.Drawing.Color.FromArgb(0, 0, 0)}}
        End If
        My.Settings.Lights = NumericUpDown1.Value
        My.Settings.Save()
        Form1.Timer1.Interval = My.Settings.Rate
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub SettingsScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NumericUpDown2.Value = My.Settings.Rate
        NumericUpDown1.Value = My.Settings.Lights
    End Sub
End Class