﻿Imports System.Drawing
Module Module1
    Public time As Integer = 0
    Public plan(,) As Color = {{Color.FromArgb(0, 0, 0)}}
    Public options As Byte = 1
End Module
