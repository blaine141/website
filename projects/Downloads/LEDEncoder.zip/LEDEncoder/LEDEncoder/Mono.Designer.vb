﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Mono
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FadeButton = New System.Windows.Forms.RadioButton()
        Me.FlashButton = New System.Windows.Forms.RadioButton()
        Me.SolidButton = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'FadeButton
        '
        Me.FadeButton.AutoSize = True
        Me.FadeButton.Location = New System.Drawing.Point(13, 60)
        Me.FadeButton.Name = "FadeButton"
        Me.FadeButton.Size = New System.Drawing.Size(49, 17)
        Me.FadeButton.TabIndex = 12
        Me.FadeButton.Text = "Fade"
        Me.FadeButton.UseVisualStyleBackColor = True
        '
        'FlashButton
        '
        Me.FlashButton.AutoSize = True
        Me.FlashButton.Location = New System.Drawing.Point(13, 37)
        Me.FlashButton.Name = "FlashButton"
        Me.FlashButton.Size = New System.Drawing.Size(50, 17)
        Me.FlashButton.TabIndex = 11
        Me.FlashButton.Text = "Flash"
        Me.FlashButton.UseVisualStyleBackColor = True
        '
        'SolidButton
        '
        Me.SolidButton.AutoSize = True
        Me.SolidButton.Checked = True
        Me.SolidButton.Location = New System.Drawing.Point(13, 14)
        Me.SolidButton.Name = "SolidButton"
        Me.SolidButton.Size = New System.Drawing.Size(48, 17)
        Me.SolidButton.TabIndex = 10
        Me.SolidButton.TabStop = True
        Me.SolidButton.Text = "Solid"
        Me.SolidButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(118, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 23)
        Me.Label1.TabIndex = 9
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(197, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Pick color"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(46, 109)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Ok"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(161, 109)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "Cancel"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Mono
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 154)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.FadeButton)
        Me.Controls.Add(Me.FlashButton)
        Me.Controls.Add(Me.SolidButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Mono"
        Me.Text = "Mono"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FadeButton As System.Windows.Forms.RadioButton
    Friend WithEvents FlashButton As System.Windows.Forms.RadioButton
    Friend WithEvents SolidButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
End Class
