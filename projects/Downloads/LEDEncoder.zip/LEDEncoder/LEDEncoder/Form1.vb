﻿Imports System.Drawing
Public Class Form1
    Private MyImage As Bitmap
    Private MyGraphic As Graphics
    Private Sub LightsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LightsToolStripMenuItem.Click
        Dim fd = New System.Windows.Forms.SaveFileDialog()
        Dim strFileName As String

        fd.Title = "Save File Dialog"
        If My.Computer.FileSystem.DirectoryExists("I:\") Then
            fd.InitialDirectory = "I:\"
        Else
            fd.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        End If
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FileName = "led.cfg"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True
        Dim out As List(Of Byte) = New List(Of Byte)

        out.Add(1)
        out.Add(My.Settings.Lights)
        out.Add(options)
        out.Add(My.Settings.Rate)
        For Each c In plan
            out.Add(c.R)
            out.Add(c.G)
            out.Add(c.B)
        Next
        If fd.ShowDialog() = DialogResult.OK Then
            Dim fs As System.IO.FileStream
            fs = New System.IO.FileStream(fd.FileName, System.IO.FileMode.Create)
            fs.Write(out.ToArray, 0, out.Count)
            fs.Close()
        End If
    End Sub


    Private Sub SettingsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SettingsToolStripMenuItem1.Click
        SettingsScreen.Show()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Mono.Show()
    End Sub

 
    Private Sub Label1_Paint(sender As Object, e As Windows.Forms.PaintEventArgs) Handles Me.Paint
        animate()
    End Sub
    Public Sub animate()
        Dim pennew As SolidBrush
        If time >= plan.GetLength(0) Then
            time = 0
        End If
        For led = 0 To My.Settings.Lights - 1
            If (options And 1) Then
                pennew = New SolidBrush(plan(time, 0))
            Else
                pennew = New SolidBrush(plan(time, led))
            End If
            MyGraphic.FillRectangle(pennew, New Rectangle(New Point(PictureBox1.Width / My.Settings.Lights * led, 0), New Size(PictureBox1.Width / My.Settings.Lights + 1, PictureBox1.Height)))
        Next
        PictureBox1.Image = MyImage
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.Rate = 0 Then
            My.Settings.Rate = 10
            My.Settings.Save()
        End If
        Timer1.Interval = My.Settings.Rate
        Timer1.Enabled = True
        MyImage = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        MyGraphic = Graphics.FromImage(MyImage)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        time += 1
        animate()
    End Sub

    
    Private Sub UpdateRateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateRateToolStripMenuItem.Click
        Dim fd = New System.Windows.Forms.OpenFileDialog()
        Dim strFileName As String

        fd.Title = "Open File Dialog"
        If My.Computer.FileSystem.DirectoryExists("I:\") Then
            fd.InitialDirectory = "I:\"
        Else
            fd.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        End If
        fd.Filter = "LED files (*.cfg)|*.cfg"
        fd.FileName = "led.cfg"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True
        
        If fd.ShowDialog() = DialogResult.OK Then
            Dim bytes() As Byte = My.Computer.FileSystem.ReadAllBytes(fd.FileName)
            options = bytes(2)
            My.Settings.Rate = bytes(3)
            My.Settings.Save()
            If options And 1 <> 0 Then
                plan = New Color(bytes.Length / 3 - 2, 0) {}
            Else
                plan = New Color(bytes.Length / 60 / 3 - 1, 59) {}
            End If
            Dim col As Integer = 0
            Dim row As Integer = 0
            For pointer As Integer = 1 To bytes.Length / 3 - 1
                Dim c As Color = Color.FromArgb(bytes(pointer * 3 - 1), bytes(pointer * 3), bytes(pointer * 3 + 1))
                plan(row, col) = c
                col += 1
                If col >= plan.GetLength(1) Then
                    col = 0
                    row += 1
                End If
            Next
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        pic.Show()
    End Sub
End Class