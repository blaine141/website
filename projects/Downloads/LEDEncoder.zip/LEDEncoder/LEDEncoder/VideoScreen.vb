﻿Imports Microsoft.DirectX.AudioVideoPlayback


Public Class VideoScreen

    Private Sub Video_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim videoFile As Video = New Video("G:/Shared Data/myvid-2012.avi")
        'videoFile.Owner = Panel1
        'videoFile.Play()
    End Sub
End Class