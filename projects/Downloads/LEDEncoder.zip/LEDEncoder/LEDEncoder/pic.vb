﻿Imports System.Drawing
Imports System.IO
Imports System.IO.Ports
Imports System.Threading
Public Class pic
    Dim WithEvents SerialPort As New IO.Ports.SerialPort
    Delegate Sub myMethodDelegate(ByVal [text] As String)
    'Dim bD1 As New myMethodDelegate(AddressOf process)
    Dim colors As List(Of Color(,)) = New List(Of Color(,))
    Dim colorIndex As Integer = 0
    Dim i As Integer = 0
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fd = New System.Windows.Forms.OpenFileDialog()
        Dim strFileName As String

        fd.Title = "Open File Dialog"

        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            PictureBox1.Image = Image.FromFile(fd.FileName)

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ScrollRight.Checked Or ScrollLeft.Checked Then
            plan = New Color(My.Settings.Lights - 1, My.Settings.Lights - 1) {}
        Else
            plan = New Color(0, My.Settings.Lights - 1) {}
        End If
        Dim img = New Bitmap(PictureBox1.Image)
        options = options And 254
        For i As Integer = 0 To My.Settings.Lights - 1
            Dim totalR As Integer = 0
            Dim totalG As Integer = 0
            Dim totalB As Integer = 0
            Dim totalPixels As Integer = 0
            For x As Integer = img.Width / My.Settings.Lights * i To img.Width / My.Settings.Lights * (i + 1) - 1
                For y As Integer = 0 To img.Height - 1
                    Dim pixel As Color = img.GetPixel(x, y)
                    totalR += pixel.R
                    totalG += pixel.G
                    totalB += pixel.B
                    totalPixels += 1
                Next
            Next
            Dim averageR As Integer = totalR \ totalPixels
            Dim averageg As Integer = totalG \ totalPixels
            Dim averageb As Integer = totalB \ totalPixels
            plan(0, i) = Color.FromArgb(averageR, averageg, averageb)
        Next
        If ScrollLeft.Checked Then
            For i As Integer = 1 To My.Settings.Lights - 1
                For x As Integer = 0 To My.Settings.Lights - 2
                    plan(i, x) = plan(i - 1, x + 1)
                Next
                plan(i, My.Settings.Lights - 1) = plan(i - 1, 0)
            Next
        ElseIf ScrollRight.Checked Then
            For i As Integer = 1 To My.Settings.Lights - 1
                For x As Integer = 1 To My.Settings.Lights - 1
                    plan(i, x) = plan(i - 1, x - 1)
                Next
                plan(i, 0) = plan(i - 1, My.Settings.Lights - 1)
            Next
        End If
        Me.Close()
    End Sub
    'Private Sub process(str As String)
    '    If str.Chars(0) = "!" Then
    '        colorIndex = 0
    '        i = 0
    '        Label1.Text = "Sending"
    '        Label1.Refresh()
    '        Dim img = New Bitmap(PictureBox1.Image)

    '        For i As Integer = 1 To 128
    '            For light As Integer = 0 To 34
    '                Dim x As Integer = Math.Cos(2 * Math.PI * (i - 1) / 128 + 2 * Math.PI / 3) * img.Width / 2 / 36 * (36 - light) + img.Width / 2
    '                Dim y As Integer = Math.Sin(2 * Math.PI * (i - 1) / 128 + 2 * Math.PI / 3) * img.Height / -2 / 36 * (36 - light) + img.Height / 2
    '                If x >= img.Width Then x = img.Width - 1
    '                If y >= img.Height Then y = img.Height - 1
    '                red(i, light) = img.GetPixel(x, y).R
    '                blue(i, light) = img.GetPixel(x, y).B
    '                green(i, light) = img.GetPixel(x, y).G
    '            Next
    '        Next
    '    End If
    '    If (str.Chars(0) = "!" Or str.Chars(0) = "~") And colorIndex <> 3 Then
    '        For light As Integer = 0 To 34
    '            If colorIndex = 0 Then
    '                SerialPort.Write(Chr(red(i, light)))
    '            End If
    '            If colorIndex = 1 Then
    '                SerialPort.Write(Chr(green(i, light)))
    '            End If
    '            If colorIndex = 2 Then
    '                SerialPort.Write(Chr(blue(i, light)))
    '            End If
    '        Next
    '        i += 1
    '        If i = 129 Then
    '            i = 0
    '            colorIndex += 1
    '        End If
    '        ProgressBar1.Value = (colorIndex * 128 + i)
    '        ProgressBar1.Refresh()
    '    End If
    '    If colorIndex = 3 Then
    '        Label1.Text = "Done!"
    '        Label1.Refresh()
    '    End If
    'End Sub
    'Private Sub SerialPort_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort.DataReceived
    'Dim str As String = SerialPort.ReadExisting()
    'Invoke(bD1, str)
    'End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'If PictureBox1.Image Is Nothing Then
        '    MsgBox("No Image Selected")
        '    Return
        'End If
        'Label1.Text = "Connecting to the wheel"
        'Label1.Refresh()
        'Try

        '    SerialPort.PortName = "COM3"
        '    SerialPort.BaudRate = 9600
        '    SerialPort.DataBits = 8
        '    SerialPort.Parity = Parity.None
        '    SerialPort.StopBits = StopBits.One
        '    SerialPort.Handshake = Handshake.None
        '    SerialPort.Encoding = System.Text.Encoding.Default
        '    SerialPort.Open()
        'Catch ex As Exception
        '    Label1.Text = "Failed to connect"
        '    Console.WriteLine(ex.ToString)
        '    Return
        'End Try
        'Label1.Text = "Connected with errors. Restart the wheel."
        'Label1.Refresh()
        'SerialPort.Write("?")
        Dim img = New Bitmap(PictureBox1.Image)
        Dim array As Color(,) = New Color(128, 35) {}
        For i As Integer = 1 To 128
            For light As Integer = 0 To 34
                Dim x As Integer = Math.Cos(2 * Math.PI * (i - 1) / 128 - 5 * Math.PI / 12) * img.Width / 2 / 36 * (36 - light) + img.Width / 2
                Dim y As Integer = Math.Sin(2 * Math.PI * (i - 1) / 128 - 5 * Math.PI / 12) * img.Height / -2 / 36 * (36 - light) + img.Height / 2
                If x >= img.Width Then x = img.Width - 1
                If y >= img.Height Then y = img.Height - 1
                array(i, light) = img.GetPixel(x, y)
            Next
        Next
        colors.Add(array)
    End Sub

    Private Sub pic_FormClosing(sender As Object, e As Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If SerialPort.IsOpen Then
            SerialPort.Close()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim s As StringWriter = New StringWriter
        s.WriteLine("int8 const NUM_OF_SLIDES = " & colors.Count & ";")
        While colors.Count < 7
            colors.Add(New Color(128, 35) {})
        End While
        For c As Integer = 0 To 6
            s.WriteLine("int8 const Red" & c & "[129][NUM_OF_LIGHTS] = ")

            s.WriteLine("{")
            For i As Integer = 0 To 128
                s.Write("{")
                For light As Integer = 0 To 34
                    If light <> 34 Then
                        s.Write(colors(c)(i, light).R & ",")
                    Else
                        s.WriteLine(colors(c)(i, light).R & "},")
                    End If
                Next
            Next

            s.WriteLine("};")
            s.WriteLine("int8 const Green" & c & "[129][NUM_OF_LIGHTS] = ")
            s.WriteLine("{")
            For i As Integer = 0 To 128
                s.Write("{")
                For light As Integer = 0 To 34
                    If light <> 34 Then
                        s.Write(colors(c)(i, light).G & ",")
                    Else
                        s.WriteLine(colors(c)(i, light).G & "},")
                    End If
                Next
            Next
            s.WriteLine("};")
            s.WriteLine("int8 const Blue" & c & "[129][NUM_OF_LIGHTS] =")
            s.WriteLine("{")
            For i As Integer = 0 To 128
                s.Write("{")
                For light As Integer = 0 To 34
                    If light <> 34 Then
                        s.Write(colors(c)(i, light).B & ",")
                    Else
                        s.WriteLine(colors(c)(i, light).B & "},")
                    End If
                Next
            Next
            s.WriteLine("};")
        Next
        colors.Clear()
        File.WriteAllText("L:\Desktop\Pic.h", s.ToString)
    End Sub
End Class