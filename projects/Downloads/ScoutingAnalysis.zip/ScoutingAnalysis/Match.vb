﻿Public Class Match
    Public num As Integer
    Public redTeam1 As Integer
    Public redTeam2 As Integer
    Public redTeam3 As Integer
    Public blueTeam1 As Integer
    Public blueTeam2 As Integer
    Public blueTeam3 As Integer
End Class
