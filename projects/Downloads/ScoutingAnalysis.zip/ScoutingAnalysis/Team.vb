﻿Public Class Team
    Public number As Integer
    Public records As List(Of Record) = New List(Of Record)
    Public totalGearTime As Double = 0
    Public totalGearScore As Integer = 0
    Public averageClimbTime As Double = 0
    Private timesClimbed As Integer = 0
    Public climbAccuracy As Double = 0
    Public totalFuelTime As Double = 0
    Public totalFuelScore As Double = 0
    Public gearEfficiency As Double = 0
    Public fuelEfficiency As Double = 0
    Public averageAutoGear As Double = 0
    Public crossLineAccuracy As Double = 0
    Public averageAutoFuel As Double = 0
    Public defenseBottom As Integer = 0
    Public defenseTop As Integer = 0
    Public defenseLeft As Integer = 0
    Public defenseRight As Integer = 0
    Public defenseCrossRight As Integer = 0
    Public defenseCrossLeft As Integer = 0
    Public numberOfScoutedRecords As Integer = 0
    Public Sub calculate(fuelstuff As Dictionary(Of Integer, FuelData))
        For Each rec As Record In records
            rec.calculate(fuelstuff)
            totalGearTime += rec.gearTime
            totalGearScore += rec.gearScore
            averageClimbTime += rec.climbTime
            If rec.climbTime <> 0 Then
                timesClimbed += 1
            End If
            If rec.climbSuccess Then
                climbAccuracy += 1
            End If
            If Not rec.noFuelScoutInfo Then
                totalFuelTime += rec.fuelTime
                totalFuelScore += rec.fuelScore
                numberOfScoutedRecords += 1
            End If
            averageAutoGear += -1 * rec.autoGear
            averageAutoFuel += rec.autoFuel
            crossLineAccuracy += -1 * rec.autoLine
            If rec.alliance = True Then
                defenseCrossLeft += rec.defenseCrossLeft
                defenseCrossRight += rec.defenseCrossRight
                defenseLeft += rec.defenseLeft
                defenseRight += rec.defenseRight
            Else
                defenseCrossLeft += rec.defenseCrossRight
                defenseCrossRight += rec.defenseCrossLeft
                defenseLeft += rec.defenseRight
                defenseRight += rec.defenseLeft
            End If
            defenseBottom += rec.defenseBottom
            defenseTop += rec.defenseTop
        Next
        If totalGearTime <> 0 Then
            gearEfficiency = totalGearScore / totalGearTime / 2
        End If
        If totalFuelTime <> 0 Then
            fuelEfficiency = totalFuelScore / totalFuelTime
        End If
        If timesClimbed <> 0 Then
            averageClimbTime /= timesClimbed
            climbAccuracy /= timesClimbed
        End If
        averageAutoGear /= records.Count
        averageAutoFuel /= records.Count
        crossLineAccuracy /= records.Count
        If numberOfScoutedRecords = 0 Then
            numberOfScoutedRecords = 1
            totalFuelScore = 0
        End If
    End Sub
End Class
