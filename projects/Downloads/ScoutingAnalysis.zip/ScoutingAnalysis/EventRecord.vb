﻿Public Class EventRecord
    Public startTime As Double
    Public stopTime As Double
    Public action As String
    Public result As String
End Class
