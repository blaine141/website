﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Web.Script.Serialization
Public Class Form1
    Public scoutDirectory As String = System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.MyDocuments, "Scouting")
    Public teamScoutFile1 As String = System.IO.Path.Combine(scoutDirectory, "Drupal Exports\scout1.json")
    Public teamScoutFile2 As String = System.IO.Path.Combine(scoutDirectory, "Drupal Exports\scout2.json")
    Public teamScoutFile3 As String = System.IO.Path.Combine(scoutDirectory, "Drupal Exports\scout3.json")
    Public fuelScoutFile As String = System.IO.Path.Combine(scoutDirectory, "Drupal Exports\fuel.json")
    Public records As List(Of Record) = New List(Of Record)()
    Public fuelStuff As Dictionary(Of Integer, FuelData) = New Dictionary(Of Integer, FuelData)
    Public teams As Dictionary(Of Integer, Team) = New Dictionary(Of Integer, Team)
    Public matches As Dictionary(Of Integer, Match) = New Dictionary(Of Integer, Match)
    Private Const WM_DEVICECHANGE As Integer = &H219
    Private Const DBT_DEVICEARRIVAL As Integer = &H8000
    Private Const DBT_DEVICEREMOVECOMPLETE As Integer = &H8004
    Private Const DBT_DEVTYP_VOLUME As Integer = &H2  '
    '
    'Get the information about the detected volume.
    Private Structure DEV_BROADCAST_VOLUME

        Dim Dbcv_Size As Integer

        Dim Dbcv_Devicetype As Integer

        Dim Dbcv_Reserved As Integer

        Dim Dbcv_Unitmask As Integer

        Dim Dbcv_Flags As Short

    End Structure
    Private Sub Download(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False
        Try
            If My.Computer.Network.IsAvailable = True Then
                If My.Computer.Network.Ping("8.8.8.8") Then
                    If File.Exists(teamScoutFile1) Then
                        File.Delete(teamScoutFile1)
                    End If
                    If File.Exists(teamScoutFile2) Then
                        File.Delete(teamScoutFile2)
                    End If
                    If File.Exists(teamScoutFile3) Then
                        File.Delete(teamScoutFile3)
                    End If
                    Dim webClient As New WebClient()
                    Dim resByte As Byte()
                    Dim resString As String = ""
                    Dim reqString() As Byte
                    Try
                        webClient.Headers("content-type") = "application/json"
                        reqString = Encoding.Default.GetBytes("{""matchB"":1,""matchT"":25}")
                        resByte = webClient.UploadData("http://ozone.worthconsulting.com/matches", "post", reqString)
                        resString = Encoding.Default.GetString(resByte)
                        webClient.Dispose()
                    Catch ex As Exception
                        Console.WriteLine(ex.Message)
                    End Try
                    File.WriteAllText(teamScoutFile1, resString)
                    Try
                        webClient.Headers("content-type") = "application/json"
                        reqString = Encoding.Default.GetBytes("{""matchB"":25,""matchT"":50}")
                        resByte = webClient.UploadData("http://ozone.worthconsulting.com/matches", "post", reqString)
                        resString = Encoding.Default.GetString(resByte)
                        webClient.Dispose()
                    Catch ex As Exception
                        Console.WriteLine(ex.Message)
                    End Try
                    File.WriteAllText(teamScoutFile2, resString)
                    Try
                        webClient.Headers("content-type") = "application/json"
                        reqString = Encoding.Default.GetBytes("{""matchB"":50,""matchT"":75}")
                        resByte = webClient.UploadData("http://ozone.worthconsulting.com/matches", "post", reqString)
                        resString = Encoding.Default.GetString(resByte)
                        webClient.Dispose()
                    Catch ex As Exception
                        Console.WriteLine(ex.Message)
                    End Try
                    File.WriteAllText(teamScoutFile3, resString)
                    If File.Exists(fuelScoutFile) Then
                        File.Delete(fuelScoutFile)
                    End If
                    My.Computer.Network.DownloadFile(
                    "http://ozone.worthconsulting.com/fuel_reports",
                    fuelScoutFile)
                Else
                    MsgBox("Could not connect to dat dere interwebs")
                End If
            Else
                MsgBox("Could not connect to dat dere interwebs")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Button1.Enabled = True
    End Sub

    Private Sub Calculate(sender As Object, e As EventArgs) Handles Button2.Click
        fuelStuff.Clear()
        teams.Clear()
        records.Clear()
        matches.Clear()
        Dim MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(System.IO.Path.Combine(scoutDirectory, "Assignments.csv"))
        MyReader.TextFieldType = FileIO.FieldType.Delimited
        MyReader.SetDelimiters(",")
        Dim row As String() = MyReader.ReadFields()
        While Not MyReader.EndOfData
            row = MyReader.ReadFields
            Dim m As Match = New Match
            m.num = row(0)
            m.blueTeam1 = row(1)
            m.blueTeam2 = row(2)
            m.blueTeam3 = row(3)
            m.redTeam1 = row(4)
            m.redTeam2 = row(5)
            m.redTeam3 = row(6)
            matches.Add(m.num, m)
        End While
        MyReader.Close()
        Dim json As String = File.ReadAllText(fuelScoutFile)
        Dim o As JObject = JObject.Parse(json)
        Dim data As List(Of JToken) = o.Children().ToList()
        For Each item As JToken In data.First.First
            Try
                Dim f As FuelData = New FuelData
                f.match = item("match")
                For Each update As JToken In item("updates")
                    Dim u As FuelUpdate = New FuelUpdate
                    Try
                        u.score = update("score")
                    Catch
                    End Try
                    u.time = update("time")
                    If update("alliance") = "1" Then
                        f.redAlliance.Add(u)
                    Else
                            f.blueAlliance.Add(u)
                    End If
                Next
                Try
                    fuelStuff.Add(item("match"), f)
                Catch
                End Try

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next
        json = File.ReadAllText(teamScoutFile1)
        o = JObject.Parse(json)
        data = o.Children().ToList()
        For Each item As JToken In data.First.First
            Try
                Dim r As Record = New Record()
                Try
                    r.match = item("match_num")
                Catch
                    Continue For
                End Try
                Try
                    If CInt(item("team_number")) >= 100000 Then Continue For
                Catch
                    Continue For
                End Try
                r.number = item("team_number")
                If Not teams.ContainsKey(r.number) Then
                    teams(r.number) = New Team()
                    teams(r.number).number = r.number
                End If
                r.alliance = item("alliance") = "1"
                r.preNotes = item("pre_notes")
                r.improvements = item("improvements")
                r.postNotes = item("post_notes")
                Try
                    r.autoFuel = item("auto_fuel_points")
                Catch
                End Try
                If r.alliance Then
                    fuelStuff(item("match_num")).redStartScore += r.autoFuel
                Else
                    Try
                        fuelStuff(item("match_num")).blueStartScore += r.autoFuel
                    Catch
                        MsgBox("Hi")
                    End Try
                End If
                r.autoGear = Not (item("auto_gear") = "fail")
                r.autoLine = item("auto_crossed_line") = "1"
                records.Add(r)
                For Each eventR As JToken In item("events")
                    Dim eve As EventRecord = New EventRecord
                    eve.startTime = eventR("start")
                    eve.stopTime = eventR("stop")
                    eve.action = eventR("action")
                    eve.result = eventR("result")
                    r.events.Add(eve)
                Next
                Try
                    r.defenseBottom = item("defense_bottom")
                    r.defenseTop = item("defense_top")
                    r.defenseLeft = item("defense_left")
                    r.defenseRight = item("defense_right")
                    r.defenseCrossLeft = item("defense_cross_left")
                    r.defenseCrossRight = item("defense_cross_right")
                Catch ex As Exception
                End Try
                teams(r.number).records.Add(r)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next
        json = File.ReadAllText(teamScoutFile2)
        o = JObject.Parse(json)
        data = o.Children().ToList()
        For Each item As JToken In data.First.First
            Try
                Dim r As Record = New Record()
                Try
                    r.match = item("match_num")
                Catch
                    Continue For
                End Try
                Try
                    If CInt(item("team_number")) >= 100000 Then Continue For
                Catch
                    Continue For
                End Try
                r.number = item("team_number")
                If Not teams.ContainsKey(r.number) Then
                    teams(r.number) = New Team()
                    teams(r.number).number = r.number
                End If
                r.alliance = item("alliance") = "1"
                r.preNotes = item("pre_notes")
                r.improvements = item("improvements")
                r.postNotes = item("post_notes")
                Try
                    r.autoFuel = item("auto_fuel_points")
                Catch
                End Try
                If r.alliance Then
                    fuelStuff(item("match_num")).redStartScore += r.autoFuel
                Else
                    Try
                        fuelStuff(item("match_num")).blueStartScore += r.autoFuel
                    Catch
                        MsgBox("Hi")
                    End Try
                End If
                r.autoGear = Not (item("auto_gear") = "fail")
                r.autoLine = item("auto_crossed_line") = "1"
                records.Add(r)
                For Each eventR As JToken In item("events")
                    Dim eve As EventRecord = New EventRecord
                    eve.startTime = eventR("start")
                    eve.stopTime = eventR("stop")
                    eve.action = eventR("action")
                    eve.result = eventR("result")
                    r.events.Add(eve)
                Next
                Try
                    r.defenseBottom = item("defense_bottom")
                    r.defenseTop = item("defense_top")
                    r.defenseLeft = item("defense_left")
                    r.defenseRight = item("defense_right")
                    r.defenseCrossLeft = item("defense_cross_left")
                    r.defenseCrossRight = item("defense_cross_right")
                Catch ex As Exception
                End Try
                teams(r.number).records.Add(r)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next
        json = File.ReadAllText(teamScoutFile3)
        o = JObject.Parse(json)
        data = o.Children().ToList()
        For Each item As JToken In data.First.First
            Try
                Dim r As Record = New Record()
                Try
                    r.match = item("match_num")
                Catch
                    Continue For
                End Try
                Try
                    If CInt(item("team_number")) >= 100000 Then Continue For
                Catch
                    Continue For
                End Try
                r.number = item("team_number")
                If Not teams.ContainsKey(r.number) Then
                    teams(r.number) = New Team()
                    teams(r.number).number = r.number
                End If
                r.alliance = item("alliance") = "1"
                r.preNotes = item("pre_notes")
                r.improvements = item("improvements")
                r.postNotes = item("post_notes")
                Try
                    r.autoFuel = item("auto_fuel_points")
                Catch
                End Try
                If r.alliance Then
                    fuelStuff(item("match_num")).redStartScore += r.autoFuel
                Else
                    Try
                        fuelStuff(item("match_num")).blueStartScore += r.autoFuel
                    Catch
                        MsgBox("Hi")
                    End Try
                End If
                r.autoGear = Not (item("auto_gear") = "fail")
                r.autoLine = item("auto_crossed_line") = "1"
                records.Add(r)
                For Each eventR As JToken In item("events")
                    Dim eve As EventRecord = New EventRecord
                    eve.startTime = eventR("start")
                    eve.stopTime = eventR("stop")
                    eve.action = eventR("action")
                    eve.result = eventR("result")
                    r.events.Add(eve)
                Next
                Try
                    r.defenseBottom = item("defense_bottom")
                    r.defenseTop = item("defense_top")
                    r.defenseLeft = item("defense_left")
                    r.defenseRight = item("defense_right")
                    r.defenseCrossLeft = item("defense_cross_left")
                    r.defenseCrossRight = item("defense_cross_right")
                Catch ex As Exception
                End Try
                teams(r.number).records.Add(r)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next
        For Each t As Team In teams.Values
            t.calculate(fuelStuff)
        Next
        If Not Directory.Exists(System.IO.Path.Combine(scoutDirectory, "Outputs")) Then
            Directory.CreateDirectory(System.IO.Path.Combine(scoutDirectory, "Outputs"))
        End If
        Dim out As String = ""
        Dim sorted = From pair In teams Order By pair.Value.totalGearScore Descending
        Dim avgGearTeam As Dictionary(Of Integer, Team) = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        sorted = From pair In teams Order By pair.Value.gearEfficiency Descending
        Dim maxGearTeam As Dictionary(Of Integer, Team) = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        sorted = From pair In teams Order By pair.Value.totalFuelScore Descending
        Dim avgFuelTeam As Dictionary(Of Integer, Team) = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        sorted = From pair In teams Order By pair.Value.fuelEfficiency Descending
        Dim maxFuelTeam As Dictionary(Of Integer, Team) = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)

        For Each t As Team In teams.Values
            out += t.number & "," & t.totalFuelScore / t.numberOfScoutedRecords & "," & t.totalFuelTime / t.numberOfScoutedRecords & "," & t.fuelEfficiency & "," & t.totalGearScore / t.records.Count & "," & t.totalGearTime / t.records.Count & "," & t.gearEfficiency & "," & t.climbAccuracy & "," & t.averageClimbTime & "," & t.averageAutoGear & "," & t.crossLineAccuracy & "," & t.averageAutoFuel & "," & indexOf(avgFuelTeam, t) & "," & indexOf(maxFuelTeam, t) & "," & indexOf(avgGearTeam, t) & "," & indexOf(maxGearTeam, t) & vbNewLine
        Next
        File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Outputs\Teams.csv"), out)

        out = ""

        For Each t As Team In teams.Values
            Dim max As Integer = 1
            If t.defenseTop > max Then max = t.defenseTop
            If t.defenseBottom > max Then max = t.defenseBottom
            If t.defenseCrossLeft > max Then max = t.defenseCrossLeft
            If t.defenseCrossRight > max Then max = t.defenseCrossRight
            If t.defenseLeft > max Then max = t.defenseLeft
            If t.defenseRight > max Then max = t.defenseRight
            out += t.number & ",0,10,1,T," & t.defenseTop / max & vbNewLine
            out += t.number & ",10,10,2,T," & t.defenseTop / max & vbNewLine
            out += t.number & ",10,8.5,3,T," & t.defenseTop / max & vbNewLine
            out += t.number & ",0,8.5,4,T," & t.defenseTop / max & vbNewLine
            out += t.number & ",0,0,1,B," & t.defenseBottom / max & vbNewLine
            out += t.number & ",10,0,2,B," & t.defenseBottom / max & vbNewLine
            out += t.number & ",10,1.5,3,B," & t.defenseBottom / max & vbNewLine
            out += t.number & ",0,1.5,4,B," & t.defenseBottom / max & vbNewLine
            out += t.number & ",0,0,1,L," & t.defenseLeft / max & vbNewLine
            out += t.number & ",0,10,2,L," & t.defenseLeft / max & vbNewLine
            out += t.number & ",1,10,3,L," & t.defenseLeft / max & vbNewLine
            out += t.number & ",1,0,4,L," & t.defenseLeft / max & vbNewLine
            out += t.number & ",10,0,1,R," & t.defenseRight / max & vbNewLine
            out += t.number & ",10,10,2,R," & t.defenseRight / max & vbNewLine
            out += t.number & ",9,10,3,R," & t.defenseRight / max & vbNewLine
            out += t.number & ",9,0,4,R," & t.defenseRight / max & vbNewLine
            out += t.number & ",0,1,1,CR," & t.defenseCrossRight / max & vbNewLine
            out += t.number & ",9,10,2,CR," & t.defenseCrossRight / max & vbNewLine
            out += t.number & ",10,9,3,CR," & t.defenseCrossRight / max & vbNewLine
            out += t.number & ",1,0,4,CR," & t.defenseCrossRight / max & vbNewLine
            out += t.number & ",0,9,1,CL," & t.defenseCrossLeft / max & vbNewLine
            out += t.number & ",9,0,2,CL," & t.defenseCrossLeft / max & vbNewLine
            out += t.number & ",10,1,3,CL," & t.defenseCrossLeft / max & vbNewLine
            out += t.number & ",1,10,4,CL," & t.defenseCrossLeft / max & vbNewLine
        Next
        File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Outputs\Defense.csv"), out)


        Dim myArray As List(Of Object) = New List(Of Object)
        For Each t As Team In teams.Values
            myArray.Add(New With {Key .num = t.number,
                                  .averageFuelScore = t.totalFuelScore / t.records.Count,
                                  .averageFuelTime = t.totalFuelTime / t.records.Count,
                                  .fuelEfficiency = t.fuelEfficiency,
                                  .averageGears = t.totalGearScore / t.records.Count,
                                  .averageGearTime = t.totalGearTime / t.records.Count,
                                  .gearEfficiency = t.gearEfficiency,
                                  .climbAccuracy = t.climbAccuracy,
                                  .climbTime = t.averageClimbTime,
                                  .averageAutoGear = t.averageAutoGear,
                                  .crossLineAccuracy = t.crossLineAccuracy,
                                  .averageAutoFuel = t.averageAutoFuel})
        Next
        Dim serializer As New JavaScriptSerializer()
        Dim webClient As New WebClient()
        Dim resByte As Byte()
        Dim resString As String = ""
        Dim reqString() As Byte
        Dim uploaded As Boolean = False
        Try
            webClient.Headers("content-type") = "application/json"
            reqString = Encoding.Default.GetBytes(serializer.Serialize(myArray))
            resByte = webClient.UploadData("http://ozone.worthconsulting.com/team_calc_upload", "post", reqString)
            resString = Encoding.Default.GetString(resByte)
            webClient.Dispose()
            uploaded = True
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
        Console.WriteLine(resString)

        out = ""
        For Each m As Match In matches.Values
            Dim scores As Dictionary(Of List(Of Integer), List(Of Double)) = New Dictionary(Of List(Of Integer), List(Of Double))
            Try
                Dim team1 As Team = teams(m.redTeam1)
                Dim team2 As Team = teams(m.redTeam2)
                Dim team3 As Team = teams(m.redTeam3)
                Dim team1f As Double
                Dim team2f As Double
                Dim team3f As Double
                For team1G As Integer = 0 To team1.gearEfficiency * (135 - team1.averageClimbTime)
                    For team2G As Integer = 0 To team2.gearEfficiency * (135 - team2.averageClimbTime)
                        For team3G As Integer = 0 To team3.gearEfficiency * (135 - team3.averageClimbTime)
                            Dim gearScore As Integer = 40
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 1 Then
                                gearScore = 60
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 2 Then
                                gearScore += 40
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 2.5 Then
                                gearScore = 120
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 6 Then
                                gearScore += 40
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 12 Then
                                gearScore += 40
                            End If
                            team1f = (135 - team1.averageClimbTime) * team1.fuelEfficiency
                            team2f = (135 - team2.averageClimbTime) * team2.fuelEfficiency
                            team3f = (135 - team3.averageClimbTime) * team3.fuelEfficiency
                            If team1.gearEfficiency <> 0 Then
                                team1f = (135 - team1.averageClimbTime - team1G / team1.gearEfficiency) * team1.fuelEfficiency
                            End If
                            If team2.gearEfficiency <> 0 Then
                                team2f = (135 - team2.averageClimbTime - team2G / team2.gearEfficiency) * team2.fuelEfficiency
                            End If
                            If team3.gearEfficiency <> 0 Then
                                team3f = (135 - team3.averageClimbTime - team3G / team3.gearEfficiency) * team3.fuelEfficiency
                            End If
                            Dim scorePerGear As Double = 0
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G <> 0 Then
                                scorePerGear = (gearScore - 40) / (team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G)
                            End If
                            scores.Add(New List(Of Integer)({team1G, team2G, team3G}), New List(Of Double)({gearScore + team1f + team2f + team3f - team1G - team2G - team3G, scorePerGear}))
                        Next
                    Next
                Next
                Dim sorted2 = From pair In scores Order By pair.Value(0) Descending
                scores = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                For opt As Integer = 0 To 2
                    team1f = (135 - team1.averageClimbTime) * team1.fuelEfficiency
                    team2f = (135 - team2.averageClimbTime) * team2.fuelEfficiency
                    team3f = (135 - team3.averageClimbTime) * team3.fuelEfficiency
                    If team1.gearEfficiency <> 0 Then
                        team1f = (135 - team1.averageClimbTime - scores.Keys(opt)(0) / team1.gearEfficiency) * team1.fuelEfficiency
                    End If
                    If team2.gearEfficiency <> 0 Then
                        team2f = (135 - team2.averageClimbTime - scores.Keys(opt)(1) / team2.gearEfficiency) * team2.fuelEfficiency
                    End If
                    If team3.gearEfficiency <> 0 Then
                        team3f = (135 - team3.averageClimbTime - scores.Keys(opt)(2) / team3.gearEfficiency) * team3.fuelEfficiency
                    End If
                    out += m.num & "," & team1.number & ",""Red""," & scores.Keys(opt)(0) & "," & scores.Keys(opt)(0) * scores.Values(opt)(1) & "," & team1f & "," & opt + 1 & vbNewLine
                    out += m.num & "," & team2.number & ",""Red""," & scores.Keys(opt)(1) & "," & scores.Keys(opt)(1) * scores.Values(opt)(1) & "," & team2f & "," & opt + 1 & vbNewLine
                    out += m.num & "," & team3.number & ",""Red""," & scores.Keys(opt)(2) & "," & scores.Keys(opt)(2) * scores.Values(opt)(1) & "," & team3f & "," & opt + 1 & vbNewLine
                Next
            Catch
            End Try
            scores.Clear()
            Try
                Dim team1 As Team = teams(m.blueTeam1)
                Dim team2 As Team = teams(m.blueTeam2)
                Dim team3 As Team = teams(m.blueTeam3)
                Dim team1f As Double
                Dim team2f As Double
                Dim team3f As Double
                For team1G As Integer = 0 To team1.gearEfficiency * (135 - team1.averageClimbTime)
                    For team2G As Integer = 0 To team2.gearEfficiency * (135 - team2.averageClimbTime)
                        For team3G As Integer = 0 To team3.gearEfficiency * (135 - team3.averageClimbTime)
                            Dim gearScore As Integer = 40
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 1 Then
                                gearScore = 60
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 2 Then
                                gearScore += 40
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear >= 2.5 Then
                                gearScore = 120
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 6 Then
                                gearScore += 40
                            End If
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G >= 12 Then
                                gearScore += 40
                            End If
                            team1f = (135 - team1.averageClimbTime) * team1.fuelEfficiency
                            team2f = (135 - team2.averageClimbTime) * team2.fuelEfficiency
                            team3f = (135 - team3.averageClimbTime) * team3.fuelEfficiency
                            If team1.gearEfficiency <> 0 Then
                                team1f = (135 - team1.averageClimbTime - team1G / team1.gearEfficiency) * team1.fuelEfficiency
                            End If
                            If team2.gearEfficiency <> 0 Then
                                team2f = (135 - team2.averageClimbTime - team2G / team2.gearEfficiency) * team2.fuelEfficiency
                            End If
                            If team3.gearEfficiency <> 0 Then
                                team3f = (135 - team3.averageClimbTime - team3G / team3.gearEfficiency) * team3.fuelEfficiency
                            End If
                            Dim scorePerGear As Double = 0
                            If team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G <> 0 Then
                                scorePerGear = (gearScore - 40) / (team1.averageAutoGear + team2.averageAutoGear + team3.averageAutoGear + team1G + team2G + team3G)
                            End If
                            scores.Add(New List(Of Integer)({team1G, team2G, team3G}), New List(Of Double)({gearScore + team1f + team2f + team3f - team1G - team2G - team3G, scorePerGear}))
                        Next
                    Next
                Next
                Dim sorted2 = From pair In scores Order By pair.Value(0) Descending
                scores = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                team1f = (135 - team1.averageClimbTime) * team1.fuelEfficiency
                team2f = (135 - team2.averageClimbTime) * team2.fuelEfficiency
                team3f = (135 - team3.averageClimbTime) * team3.fuelEfficiency
                For opt As Integer = 0 To 2
                    If team1.gearEfficiency <> 0 Then
                        team1f = (135 - team1.averageClimbTime - scores.Keys(opt)(0) / team1.gearEfficiency) * team1.fuelEfficiency
                    End If
                    If team2.gearEfficiency <> 0 Then
                        team2f = (135 - team2.averageClimbTime - scores.Keys(opt)(1) / team2.gearEfficiency) * team2.fuelEfficiency
                    End If
                    If team3.gearEfficiency <> 0 Then
                        team3f = (135 - team3.averageClimbTime - scores.Keys(opt)(2) / team3.gearEfficiency) * team3.fuelEfficiency
                    End If
                    out += m.num & "," & team1.number & ",""Blue""," & scores.Keys(opt)(0) & "," & scores.Keys(opt)(0) * scores.Values(opt)(1) & "," & team1f & "," & opt + 1 & vbNewLine
                    out += m.num & "," & team2.number & ",""Blue""," & scores.Keys(opt)(1) & "," & scores.Keys(opt)(1) * scores.Values(opt)(1) & "," & team2f & "," & opt + 1 & vbNewLine
                    out += m.num & "," & team3.number & ",""Blue""," & scores.Keys(opt)(2) & "," & scores.Keys(opt)(2) * scores.Values(opt)(1) & "," & team3f & "," & opt + 1 & vbNewLine
                Next
            Catch
            End Try
        Next
        File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Outputs\Optimization.csv"), out)
        out = ""
        For Each t As Team In teams.Values
            For Each r As Record In t.records
                For Each eve As EventRecord In r.events
                    out += t.number & "," & r.match & "," & eve.startTime & "," & eve.stopTime - eve.startTime & "," & eve.action & "," & eve.result & "," & r.alliance & ",,," & vbNewLine
                Next
                out += t.number & "," & r.match & ",0,135,auto,Gear: " & r.autoGear & "    Cross Line: " & r.autoLine & "     Fuel: " & r.autoFuel & "," & r.alliance & "," & r.preNotes & "," & r.improvements & "," & r.postNotes & "," & vbNewLine
            Next
        Next
        File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Outputs\Events.csv"), out)
        File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Outputs\current.match"), NumericUpDown1.Value)
        If uploaded Then
            MsgBox("Data calculated and uploaded")
        Else
            MsgBox("Data calculated but FAILED to upload")
        End If

    End Sub

    Public Function indexOf(l As Dictionary(Of Integer, Team), t As Team) As Integer
        For i As Integer = 0 To l.Count - 1
            If l.Values(i).number = t.number Then
                Return i + 1
            End If
        Next
        Return 0
    End Function

    Private Sub Assignment_Upload(sender As Object, e As EventArgs) Handles Button3.Click
        Dim MyReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(System.IO.Path.Combine(scoutDirectory, "Assignments.csv"))
        MyReader.TextFieldType = FileIO.FieldType.Delimited
        MyReader.SetDelimiters(",")
        Dim row As String() = MyReader.ReadFields()
        Dim myArray As List(Of Object) = New List(Of Object)
        While Not MyReader.EndOfData
            row = MyReader.ReadFields
            Dim i As Integer = 7
            Dim name1 As List(Of String) = New List(Of String)
            While i < row.Count
                name1.Add(row(i))
                i += 7
            End While
            i = 8
            Dim name2 As List(Of String) = New List(Of String)
            While i < row.Count
                name2.Add(row(i))
                i += 7
            End While
            i = 9
            Dim name3 As List(Of String) = New List(Of String)
            While i < row.Count
                name3.Add(row(i))
                i += 7
            End While
            i = 10
            Dim name4 As List(Of String) = New List(Of String)
            While i < row.Count
                name4.Add(row(i))
                i += 7
            End While
            i = 11
            Dim name5 As List(Of String) = New List(Of String)
            While i < row.Count
                name5.Add(row(i))
                i += 7
            End While
            i = 12
            Dim name6 As List(Of String) = New List(Of String)
            While i < row.Count
                name6.Add(row(i))
                i += 7
            End While
            i = 13
            Dim fuel As List(Of String) = New List(Of String)
            While i < row.Count
                fuel.Add(row(i))
                i += 7
            End While
            myArray.Add(New With {Key .match = row(0), .name1 = name1, .name2 = name2, .name3 = name3, .name4 = name4, .name5 = name5, .name6 = name6, .fuel = fuel, .blue1 = row(1), .blue2 = row(2), .blue3 = row(3), .red1 = row(4), .red2 = row(5), .red3 = row(6)})
        End While
        Dim serializer As New JavaScriptSerializer()
        Dim webClient As New WebClient()
        Dim resByte As Byte()
        Dim resString As String = ""
        Dim reqString() As Byte
        Try
            webClient.Headers("content-type") = "application/json"
            reqString = Encoding.Default.GetBytes(serializer.Serialize(myArray))
            resByte = webClient.UploadData("http://ozone.worthconsulting.com/assignment_upload", "post", reqString)
            resString = Encoding.Default.GetString(resByte)
            webClient.Dispose()
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
        MsgBox(resString)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not (Directory.Exists(scoutDirectory)) Then
            Directory.CreateDirectory(scoutDirectory)
        End If
        If Not File.Exists(scoutDirectory & "\Assignments.csv") Then
            File.WriteAllText(System.IO.Path.Combine(scoutDirectory, "Assignments.csv"), "Match,Blue1,Blue2,Blue3,Red1,Red2,Red3,Name1,Name2,Name3,Name4,Name5,Name6,Fuel")
        End If
    End Sub
    Protected Overrides Sub WndProc(ByRef M As System.Windows.Forms.Message)
        '
        'These are the required subclassing codes for detecting device based removal and arrival.
        '
        If M.Msg = WM_DEVICECHANGE Then

            Select Case M.WParam
                '
                'Check if a device was added.
                Case DBT_DEVICEARRIVAL

                    Dim DevType As Integer = Runtime.InteropServices.Marshal.ReadInt32(M.LParam, 4)

                    If DevType = DBT_DEVTYP_VOLUME Then

                        Dim Vol As New DEV_BROADCAST_VOLUME

                        Vol = Runtime.InteropServices.Marshal.PtrToStructure(M.LParam, GetType(DEV_BROADCAST_VOLUME))

                        If Vol.Dbcv_Flags = 0 Then

                            For i As Integer = 0 To 20

                                If Math.Pow(2, i) = Vol.Dbcv_Unitmask Then

                                    Dim Usb As String = Chr(65 + i) + ":\"
                                    If Not Directory.Exists(Usb & "Scouting") Then
                                        Directory.CreateDirectory(Usb & "Scouting")
                                    End If
                                    File.Copy(System.IO.Path.Combine(scoutDirectory, "Outputs\Teams.csv"), Usb & "Scouting\Teams.csv", True)
                                    File.Copy(System.IO.Path.Combine(scoutDirectory, "Outputs\Events.csv"), Usb & "Scouting\Events.csv", True)
                                    File.Copy(System.IO.Path.Combine(scoutDirectory, "Outputs\Optimization.csv"), Usb & "Scouting\Optimization.csv", True)
                                    File.Copy(System.IO.Path.Combine(scoutDirectory, "Outputs\current.match"), Usb & "Scouting\current.match", True)
                                    MsgBox("Copied")
                                    Exit For

                                End If

                            Next

                        End If

                    End If

            End Select

        End If

        MyBase.WndProc(M)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Try
            If My.Computer.Network.IsAvailable = True Then
                If My.Computer.Network.Ping("8.8.8.8") Then
                    If File.Exists(System.IO.Path.Combine(scoutDirectory, "Assignments.csv")) Then
                        File.Delete(System.IO.Path.Combine(scoutDirectory, "Assignments.csv"))
                    End If
                    My.Computer.Network.DownloadFile(
                    "http://ozone.worthconsulting.com/assignments_csv",
                    System.IO.Path.Combine(scoutDirectory, "Assignments.csv"))
                Else
                    MsgBox("Could not connect to dat dere interwebs")
                End If
            Else
                MsgBox("Could not connect to dat dere interwebs")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
            Return
        End Try
    End Sub
End Class
