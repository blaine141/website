﻿Public Class FuelUpdate
    Public time As Double
    Public score As Double = 0
End Class
