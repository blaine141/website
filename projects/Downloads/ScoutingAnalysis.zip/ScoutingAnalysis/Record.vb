﻿Public Class Record
    Public number As Integer
    Public match As Integer
    Public alliance As Boolean 'red is true
    Public autoGear As Boolean
    Public autoLine As Boolean
    Public autoFuel As Double = 0
    Public events As List(Of EventRecord) = New List(Of EventRecord)()
    Public gearScore As Integer
    Public gearTime As Double
    Public climbTime As Double
    Public climbSuccess As Boolean
    Public fuelTime As Integer
    Public fuelScore As Double
    Public preNotes As String
    Public postNotes As String
    Public improvements As String
    Public defenseBottom As Integer = 0
    Public defenseTop As Integer = 0
    Public defenseLeft As Integer = 0
    Public defenseRight As Integer = 0
    Public defenseCrossRight As Integer = 0
    Public defenseCrossLeft As Integer = 0
    Public noFuelScoutInfo As Boolean = False
    Public Sub New()
    End Sub
    Public Sub calculate(fuelstuff As Dictionary(Of Integer, FuelData))
        gearTime = 0
        gearScore = 0
        climbTime = 0
        fuelTime = 0
        For Each e As EventRecord In events
            If e.action = "gears" Or e.action = "gear" Then
                If e.result <> "fail" Then
                    gearScore += 1
                End If
                gearTime += e.stopTime - e.startTime
                For Each eTwo As EventRecord In events
                    If eTwo.startTime > e.startTime And eTwo.stopTime <= e.stopTime Then
                        gearTime -= eTwo.stopTime - eTwo.startTime
                    End If
                Next
            End If
            If e.action = "climb" Then
                climbTime = e.stopTime - e.startTime
                climbSuccess = (e.result <> "fail")
            End If
            If e.action = "collect" Or e.action = "shoot" Then
                fuelTime += e.stopTime - e.startTime
                If e.action = "shoot" Then
                    Dim updates
                    e.result = ""
                    Dim lastScore As Integer
                    If alliance Then
                        updates = fuelstuff(match).redAlliance
                        lastScore = fuelstuff(match).redStartScore
                    Else
                        updates = fuelstuff(match).blueAlliance
                        lastScore = fuelstuff(match).blueStartScore
                    End If

                    For Each f As FuelUpdate In updates
                        If f.time > e.stopTime Then
                            e.result = f.score - lastScore
                            fuelScore += f.score - lastScore
                            Exit For
                        End If
                        lastScore = f.score
                    Next
                    If e.result = "" Then
                        noFuelScoutInfo = True
                    End If
                End If
            End If
        Next
    End Sub
End Class
