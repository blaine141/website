﻿Public Class FuelData
    Public match As Integer
    Public redStartScore As Double
    Public blueStartScore As Double
    Public redAlliance As List(Of FuelUpdate) = New List(Of FuelUpdate)
    Public blueAlliance As List(Of FuelUpdate) = New List(Of FuelUpdate)
End Class
